/**
 * @file vm.h
 * @brief DESF Virtual Machine: executes .desf bytecode
 * @author Ferki
 * @license MIT
 *
 * 🚀 Zero-dependencies • 🔧 Hardware-agnostic • 🧠 AI-Ready
 */

#ifndef DESF_VM_H
#define DESF_VM_H

#include "desf/commands.h"
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

//═════════════════════════════════════════════════════════════════════════════
//                            VM Configuration
//═════════════════════════════════════════════════════════════════════════════

#define DESF_MEM_SIZE        4096  ///< Memory size (bytes)
#define DESF_MAX_REGISTERS   16    ///< Registers count
#define DESF_MAX_PLUGINS     16    ///< Plugins maximum
#define DESF_MAX_DEVICES     4     ///< Devices maximum

/// Optimization flags (bitmask)
typedef uint32_t DesfOptimizationFlags;
#define DESF_OPT_NONE         0      ///< No optimization
#define DESF_OPT_JIT_ENABLE   (1 << 0) ///< Enable JIT compilation
#define DESF_OPT_CACHE_ENABLE (1 << 1) ///< Enable caching

//═════════════════════════════════════════════════════════════════════════════
//                           Core VM Structures
//═════════════════════════════════════════════════════════════════════════════

/// Status register flags
enum {
    DESF_STATUS_ZERO  = 0x01,  ///< Zero flag
    DESF_STATUS_CARRY = 0x02,  ///< Carry flag
    DESF_STATUS_ERROR = 0x04,  ///< Error flag
    DESF_STATUS_HALT  = 0x08   ///< Halt flag
};

/// Virtual machine state
typedef struct {
    uint8_t memory[DESF_MEM_SIZE];      ///< Unified memory space
    int32_t registers[DESF_MAX_REGISTERS]; ///< General-purpose registers
    uint32_t pc;                        ///< Program counter
    uint8_t status_flags;               ///< Status flags (bitmask)
    DesfOptimizationFlags optimizations; ///< Optimization flags
} DesfVMState;

/// Device mapping entry
typedef struct {
    DesfIOHandler handler;      ///< Device handler function
    uint32_t base_address;      ///< Memory-mapped base address
} DesfDeviceEntry;

/// Virtual machine context
typedef struct {
    DesfVMState state;                      ///< Current VM state
    DesfPluginHandler plugins[DESF_MAX_PLUGINS]; ///< Plugin handlers
    DesfDeviceEntry devices[DESF_MAX_DEVICES];   ///< Device mappings
    size_t num_devices;                     ///< Active device count
} DesfVirtualMachine;

//═════════════════════════════════════════════════════════════════════════════
//                      Hardware Abstraction Layer
//═════════════════════════════════════════════════════════════════════════════

/**
 * @brief Universal I/O callback for peripherals
 * @param address Memory-mapped address
 * @param data Data buffer for write (NULL for read)
 * @param size Data size in bytes
 * @return Operation status or read value
 */
typedef int32_t (*DesfIOHandler)(uint32_t address, const uint8_t *data, size_t size);

//═════════════════════════════════════════════════════════════════════════════
//                           Public API
//═════════════════════════════════════════════════════════════════════════════

/**
 * @brief Initialize virtual machine
 * @param vm Virtual machine context
 * @param init_mem Initial memory image (NULL for zero-initialized)
 */
void desf_vm_init(DesfVirtualMachine *vm, const uint8_t *init_mem);

/**
 * @brief Execute .desf program
 * @param vm Virtual machine context
 * @param program Command array
 * @param count Number of commands
 * @return 0 on success, error code on failure
 */
int desf_vm_execute(DesfVirtualMachine *vm, const DesfCommand *program, size_t count);

/**
 * @brief Map hardware device to memory
 * @param vm Virtual machine context
 * @param handler Device handler function
 * @param base_address Memory-mapped base address
 * @return 0 on success, error code if device slots full
 */
int desf_vm_map_device(DesfVirtualMachine *vm, DesfIOHandler handler, uint32_t base_address);

/**
 * @brief Load plugin into VM
 * @param vm Virtual machine context
 * @param handler Plugin entry point
 * @return 0 on success, error code if plugin slots full
 */
int desf_vm_load_plugin(DesfVirtualMachine *vm, DesfPluginHandler handler);

/**
 * @brief Read from VM memory
 * @param vm Virtual machine context
 * @param address Source address
 * @param buffer Destination buffer
 * @param size Bytes to read
 * @return 0 on success, error code if out of bounds
 */
int desf_vm_mem_read(const DesfVirtualMachine *vm, uint32_t address, uint8_t *buffer, size_t size);

/**
 * @brief Write to VM memory
 * @param vm Virtual machine context
 * @param address Destination address
 * @param data Source buffer
 * @param size Bytes to write
 * @return 0 on success, error code if out of bounds
 */
int desf_vm_mem_write(DesfVirtualMachine *vm, uint32_t address, const uint8_t *data, size_t size);

#ifdef __cplusplus
}
#endif

#endif // DESF_VM_H