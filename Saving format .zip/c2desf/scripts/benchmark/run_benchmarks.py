# -*- coding: utf-8 -*-
"""
=================================================
 Amplius Universalis Benchmark Suite (v2.0)
=================================================
 Description: Suite robusta et adaptiva ad probandum
              facultates systematum diversorum.
 Platforms: Windows, Linux, macOS, iOS, Android
 Author: Ferki + AI (Modificatione usoris inspirata)
 Lingua: Python 3.8+
 Nullae Dependentiae Externae (praeter numpy et quod systema praebet)
=================================================
"""

import os
import time
import json
import platform
import struct
import math
import hashlib
import random
import sys
import threading
import queue
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Any, Optional, Tuple
import numpy as np # Necessarium pro NeuralOptimizer

# ██╗   ██╗███████╗ ██████╗ ██████╗ ██╗   ██╗███████╗███████╗
# ██║   ██║██╔════╝██╔════╝██╔════╝ ██║   ██║██╔════╝██╔════╝
# ██║   ██║███████╗██║     ██║  ███╗██║   ██║███████╗███████╗
# ██║   ██║╚════██║██║     ██║   ██║██║   ██║╚════██║╚════██║
# ╚██████╔╝███████║╚██████╗╚██████╔╝╚██████╔╝███████║███████║
#  ╚═════╝ ╚══════╝ ╚═════╝ ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
# Systema Explorator Universalis - Ad informationem systematis colligendam

class UniversalSystemProbe:
    """
    Classis ad colligendas metricas systematis cruciales trans diversas
    systemata operativa. Utitur modulis nativis et artificiis ubi fieri potest.
    """
    _instance = None
    _lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        # Singleton pattern pro exploratore
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        """Initializat exploratorem systematis, si non iam initializatus est."""
        if self._initialized:
            return
        with self._lock:
            if self._initialized:
                return
            self._system_info = self._gather_initial_info()
            self._initialized = True
            # Add logging or print statement here if needed for initialization confirmation
            # print("Systema Explorator initializatus.")

    def _gather_initial_info(self) -> Dict[str, Any]:
        """Colligit informationem staticam systematis in initializatione."""
        info = {
            'system': platform.system(),
            'node_name': platform.node(),
            'release': platform.release(),
            'version': platform.version(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'python_version': platform.python_version(),
            'cores_logical': os.cpu_count(),
            # 'cores_physical': self._get_physical_cores(), # Methodus auxiliaris addi potest
            'ram_total_gb': self._get_total_ram_gb(),
        }
        return info

    def get_system_info(self) -> Dict[str, Any]:
        """Reddit informationem systematis iam collectam."""
        return self._system_info.copy()

    def _get_total_ram_gb(self) -> Optional[float]:
        """Conatur invenire totalem RAM in GB."""
        try:
            if platform.system() == "Linux":
                with open('/proc/meminfo', 'r') as mem:
                    lines = mem.readlines()
                for line in lines:
                    if 'MemTotal' in line:
                        # Format: MemTotal:       16300036 kB
                        total_kb = int(line.split()[1])
                        return round(total_kb / (1024 * 1024), 2)
            elif platform.system() == "Darwin":
                # sysctl hw.memsize -> hw.memsize: 17179869184 (bytes)
                mem_bytes = int(os.popen('sysctl -n hw.memsize').read().strip())
                return round(mem_bytes / (1024**3), 2)
            elif platform.system() == "Windows":
                # Requires psutil usually, using ctypes as fallback
                try:
                    import ctypes
                    kernel32 = ctypes.windll.kernel32
                    c_ulonglong = ctypes.c_ulonglong
                    class MEMORYSTATUSEX(ctypes.Structure):
                        _fields_ = [
                            ('dwLength', ctypes.c_ulong),
                            ('dwMemoryLoad', ctypes.c_ulong),
                            ('ullTotalPhys', c_ulonglong),
                            ('ullAvailPhys', c_ulonglong),
                            ('ullTotalPageFile', c_ulonglong),
                            ('ullAvailPageFile', c_ulonglong),
                            ('ullTotalVirtual', c_ulonglong),
                            ('ullAvailVirtual', c_ulonglong),
                            ('ullAvailExtendedVirtual', c_ulonglong),
                        ]
                    memory_status = MEMORYSTATUSEX()
                    memory_status.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
                    if kernel32.GlobalMemoryStatusEx(ctypes.byref(memory_status)):
                        return round(memory_status.ullTotalPhys / (1024**3), 2)
                except Exception:
                    # Fallback si ctypes fallit
                    return None # Vel valor fixus ut 4.0
            # Fallback generalis
            return None # Vel valor fixus ut 4.0
        except Exception as e:
            # print(f"Error colligendo RAM: {e}") # Debugging
            return None # Vel valor fixus ut 4.0

    def get_cpu_temperature(self) -> float:
        """
        Reddit temperaturam CPU in gradibus Celsius.
        Utilizat methodos specificas pro OS vel emulationem si necesse est.
        """
        temp = 40.0  # Valor fallback default
        system = platform.system()
        try:
            if system == 'Linux':
                # Conatur legere ex diversis zonibus thermalibus
                for i in range(5):
                    path = f'/sys/class/thermal/thermal_zone{i}/temp'
                    if os.path.exists(path):
                        with open(path, 'r') as f:
                            temp = float(f.read().strip()) / 1000.0
                        break # Utitur primo invento
                else: # Si nulla zona inventa est
                     temp = 35.0 + (os.getpid() % 15) # Emulatio lenis
            elif system == 'Darwin':
                # Praesumit 'osx-cpu-temp' installatum esse vel alium modum
                # Hoc potest fallere si instrumentum non est praesens
                process = os.popen('osx-cpu-temp 2>/dev/null') # Supprimit errorem si non invenitur
                output = process.read().strip()
                if output and '°C' in output:
                   temp = float(output.replace('°C', ''))
                else:
                    # Fallback pro Darwin si instrumentum deficit
                    temp = 38.0 + (os.getpid() % 12)
            elif system == 'Windows':
                 # Hoc est valde specificum et potest non operari in omnibus systematibus
                 # WMI esset robustior sed requirit pywin32
                try:
                    # Conatur legere temperaturam per WMI si possibile est (requirit wmi module)
                    # import wmi
                    # w = wmi.WMI(namespace="root\\wmi")
                    # results = w.MSAcpi_ThermalZoneTemperature()
                    # if results:
                    #     temp = (results[0].CurrentTemperature - 2732) / 10.0
                    # else: temp = 42.0 + (os.getpid() % 10) # Emulatio
                    # Fallback ad emulationem si WMI non est available/non operatur
                    temp = 42.0 + (os.getpid() % 10) # Emulatio robustior
                except ImportError:
                     temp = 42.0 + (os.getpid() % 10) # Emulatio si wmi non installatum est
                except Exception:
                     temp = 42.0 + (os.getpid() % 10) # Emulatio generalis pro Windows
            else:
                # Emulatio pro aliis systematibus (Android, iOS via Pythonista/Termux etc.)
                temp = 35.0 + (os.getpid() % 20)
        except Exception as e:
            # print(f"Error legendo temperaturam: {e}") # Debugging
            temp = 45.0 # Fallback extremus
        return round(temp, 1)

    def get_power_consumption(self) -> float:
        """
        Estimat consummationem potentiae in Wattis.
        Hoc est valde approximatum et plerumque emulatum.
        """
        # Emulatio simplex - potest adaptari secundum onus CPU/temp etc.
        base_power = 2.0
        dynamic_power = (time.time() % 5) * 0.8 # Variatio levis
        temp_factor = max(0, (self.get_cpu_temperature() - 40) / 50) # Factor thermalis (0 ad ~1)
        power = base_power + dynamic_power + temp_factor * 3.0 # Addit effectum thermalem
        return round(power, 2)

    def get_disk_usage(self, path: str = '.') -> Optional[Tuple[float, float]]:
        """
        Reddit spatium totale et liberum disci in GB pro via data.
        Utilizat os.statvfs in systematibus POSIX et ctypes in Windows.
        """
        try:
            if hasattr(os, 'statvfs'): # Linux, macOS, alii POSIX
                stats = os.statvfs(path)
                total = stats.f_blocks * stats.f_frsize
                available = stats.f_bavail * stats.f_frsize
                return round(total / (1024**3), 2), round(available / (1024**3), 2)
            elif platform.system() == "Windows":
                import ctypes
                free_bytes = ctypes.c_ulonglong(0)
                total_bytes = ctypes.c_ulonglong(0)
                path_w = ctypes.c_wchar_p(path)
                success = ctypes.windll.kernel32.GetDiskFreeSpaceExW(path_w,
                                                                     ctypes.byref(free_bytes),
                                                                     ctypes.byref(total_bytes),
                                                                     None)
                if success:
                    return round(total_bytes.value / (1024**3), 2), round(free_bytes.value / (1024**3), 2)
                else:
                    return None
            else:
                return None # Systema non supportatum
        except Exception as e:
            # print(f"Error legendo usum disci: {e}") # Debugging
            return None

# ███████╗██╗   ██╗███████╗███████╗███████╗███████╗ ██████╗ ███████╗
# ██╔════╝██║   ██║██╔════╝██╔════╝██╔════╝██╔════╝██╔════╝ ██╔════╝
# ███████╗██║   ██║███████╗███████╗███████╗███████╗██║  ███╗███████╗
# ╚════██║██║   ██║╚════██║╚════██║╚════██║╚════██║██║   ██║╚════██║
# ███████║╚██████╔╝███████║███████║███████║███████║╚██████╔╝███████║
# ╚══════╝ ╚═════╝ ╚══════╝╚══════╝╚══════╝╚══════╝ ╚═════╝ ╚══════╝
# Encoder Securus contra Quantum - Simplex sed demonstrativus

class QuantumSafeEncoder:
    """
    Implementatio simplex encryptionis XOR cum clavi derivata ex SHA256.
    Non est vere 'quantum-safe', sed demonstrat processum encryptionis.
    Nomen est magis aspirationale hic.
    """
    def __init__(self, key_seed: str):
        """Initializat encodorem cum semine clavis."""
        # Generat clavem robustiorem ex semine
        self.key = hashlib.sha256(key_seed.encode('utf-8')).digest() # 32 bytes

    def _xor_cipher(self, data: bytes) -> bytes:
        """Applicat operationem XOR inter data et clavem."""
        key_len = len(self.key)
        return bytes([b ^ self.key[i % key_len] for i, b in enumerate(data)])

    def encrypt(self, data: bytes) -> bytes:
        """Encryptat data utens cifra XOR."""
        # Potest addere stratos sicut padding vel IV si necesse est
        return self._xor_cipher(data)

    def decrypt(self, encrypted_data: bytes) -> bytes:
        """Decryptat data utens cifra XOR (operatio est eadem)."""
        # Decryptio XOR est eadem operatio ac encryptio
        return self._xor_cipher(encrypted_data)

    def save_encrypted(self, data_dict: Dict, filename: str):
        """
        Serializat dictionarium ad JSON, encryptat, et salvat ad fasciculum.
        Addit longitudinem datarum encryptarum in initio fasciculi.
        """
        try:
            json_data = json.dumps(data_dict, indent=None, separators=(',', ':')).encode('utf-8')
            encrypted_data = self.encrypt(json_data)
            with open(filename, 'wb') as f:
                # Scribit longitudinem datarum encryptarum (4 bytes, little-endian)
                f.write(struct.pack('<I', len(encrypted_data)))
                # Scribit ipsa data encrypta
                f.write(encrypted_data)
            # print(f"Data encrypta salvata in {filename}") # Confirmatio
        except IOError as e:
            print(f"Error scribendo fasciculum encryptum {filename}: {e}", file=sys.stderr)
        except Exception as e:
            print(f"Error generalis in save_encrypted: {e}", file=sys.stderr)

    def load_decrypted(self, filename: str) -> Optional[Dict]:
        """
        Legit fasciculum encryptum, decryptat, et deserializat JSON ad dictionarium.
        """
        try:
            with open(filename, 'rb') as f:
                # Legit longitudinem datarum encryptarum (4 bytes)
                len_bytes = f.read(4)
                if not len_bytes: return None # Fasciculus vacuus
                data_len = struct.unpack('<I', len_bytes)[0]

                # Legit ipsa data encrypta
                encrypted_data = f.read(data_len)
                if len(encrypted_data) != data_len:
                    print(f"Error: Longitudo datarum lectarum ({len(encrypted_data)}) non congruit longitudini expectatae ({data_len}) in {filename}", file=sys.stderr)
                    return None

            # Decryptat data
            decrypted_data = self.decrypt(encrypted_data)

            # Deserializat JSON
            return json.loads(decrypted_data.decode('utf-8'))
        except FileNotFoundError:
            print(f"Error: Fasciculus {filename} non inventus.", file=sys.stderr)
            return None
        except (IOError, struct.error, json.JSONDecodeError, UnicodeDecodeError) as e:
            print(f"Error legendo/decryptando fasciculum {filename}: {e}", file=sys.stderr)
            return None
        except Exception as e:
            print(f"Error generalis in load_decrypted: {e}", file=sys.stderr)
            return None

# ███╗   ██╗███████╗██╗   ██╗███████╗ ██████╗ ██╗   ██╗███████╗███████╗
# ████╗  ██║██╔════╝██║   ██║██╔════╝██╔════╝ ██║   ██║██╔════╝██╔════╝
# ██╔██╗ ██║███████╗██║   ██║███████╗██║  ███╗██║   ██║███████╗███████╗
# ██║╚██╗██║╚════██║██║   ██║╚════██║██║   ██║██║   ██║╚════██║╚════██║
# ██║ ╚████║███████║╚██████╔╝███████║╚██████╔╝╚██████╔╝███████║███████║
# ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚══════╝ ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
# Optimizator Neuralis - Simplex rete neurale pro demonstratione

class NeuralOptimizer:
    """
    Implementatio levis retis neuralis feed-forward cum uno strato celato.
    Utitur NumPy pro operationibus matricis.
    """
    def __init__(self, input_size: int = 3, hidden_size: int = 5, output_size: int = 1, learning_rate: float = 0.01):
        """Initializat rete neurale cum ponderibus aleatoriis."""
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.learning_rate = learning_rate

        # Initializatio ponderum cum distributione normali (melior quam randn purum)
        self.weights_input_hidden = np.random.randn(self.input_size, self.hidden_size) * np.sqrt(2. / self.input_size)
        self.bias_hidden = np.zeros((1, self.hidden_size))
        self.weights_hidden_output = np.random.randn(self.hidden_size, self.output_size) * np.sqrt(2. / self.hidden_size)
        self.bias_output = np.zeros((1, self.output_size))

        # Propositum placeholder pro statu interno vel adaptatione
        self._internal_state = "Initialis"

    def _sigmoid(self, x: np.ndarray) -> np.ndarray:
        """Functio activationis Sigmoid."""
        return 1 / (1 + np.exp(-np.clip(x, -500, 500))) # Clip pro stabilitate numerica

    def _sigmoid_derivative(self, x: np.ndarray) -> np.ndarray:
        """Derivativum functionis Sigmoid."""
        sig = self._sigmoid(x)
        return sig * (1 - sig)

    def predict(self, inputs: List[float]) -> float:
        """
        Facit praedictionem (forward pass) pro datis inputibus.
        Reddit unicum valorem floatum.
        """
        if len(inputs) != self.input_size:
            raise ValueError(f"Magnitudo input ({len(inputs)}) non congruit magnitudini expectatae ({self.input_size})")

        # Convertit input listam ad NumPy array (vector ordinis)
        input_vector = np.array(inputs, dtype=np.float32).reshape(1, -1)

        # Calculatio strati celati
        hidden_layer_input = np.dot(input_vector, self.weights_input_hidden) + self.bias_hidden
        hidden_layer_output = self._sigmoid(hidden_layer_input)

        # Calculatio strati output
        output_layer_input = np.dot(hidden_layer_output, self.weights_hidden_output) + self.bias_output
        predicted_output = self._sigmoid(output_layer_input) # Usus sigmoid pro output inter 0 et 1

        self._internal_state = "Praedictio facta" # Actualizat statum internum
        return float(predicted_output[0, 0]) # Reddit valorem floatum

    def train_step(self, inputs: List[float], target: float):
        """
        Placeholder pro uno gradu disciplinae (backpropagation).
        Hic non plene implementatus est ad simplicitatem servandam.
        """
        # --- Forward Pass (idem ac predict) ---
        if len(inputs) != self.input_size:
            raise ValueError(f"Magnitudo input ({len(inputs)}) non congruit magnitudini expectatae ({self.input_size})")
        input_vector = np.array(inputs, dtype=np.float32).reshape(1, -1)
        target_vector = np.array([[target]], dtype=np.float32)

        hidden_layer_input = np.dot(input_vector, self.weights_input_hidden) + self.bias_hidden
        hidden_layer_output = self._sigmoid(hidden_layer_input)
        output_layer_input = np.dot(hidden_layer_output, self.weights_hidden_output) + self.bias_output
        predicted_output = self._sigmoid(output_layer_input)

        # --- Backward Pass (Calculatio erroris et gradientium) ---
        output_error = target_vector - predicted_output
        output_delta = output_error * self._sigmoid_derivative(output_layer_input)

        hidden_error = np.dot(output_delta, self.weights_hidden_output.T)
        hidden_delta = hidden_error * self._sigmoid_derivative(hidden_layer_input)

        # --- Actualizatio Ponderum et Bias ---
        self.weights_hidden_output += np.dot(hidden_layer_output.T, output_delta) * self.learning_rate
        self.bias_output += np.sum(output_delta, axis=0, keepdims=True) * self.learning_rate
        self.weights_input_hidden += np.dot(input_vector.T, hidden_delta) * self.learning_rate
        self.bias_hidden += np.sum(hidden_delta, axis=0, keepdims=True) * self.learning_rate

        self._internal_state = f"Gradus disciplinae completus (Error: {np.mean(np.abs(output_error)):.4f})"
        # print(self._internal_state) # Optional: pro debugging

    def get_status(self) -> str:
        """Reddit statum internum optimizeris."""
        return self._internal_state

# ███████╗███████╗███╗   ███╗ ██████╗ ██╗   ██╗ ██████╗ ███████╗
# ██╔════╝██╔════╝████╗ ████║██╔════╝ ██║   ██║██╔════╝ ██╔════╝
# ███████╗███████╗██╔████╔██║██║  ███╗██║   ██║██║  ███╗███████╗
# ╚════██║╚════██║██║╚██╔╝██║██║   ██║██║   ██║██║   ██║╚════██║
# ███████║███████║██║ ╚═╝ ██║╚██████╔╝╚██████╔╝╚██████╔╝███████║
# ╚══════╝╚══════╝╚═╝     ╚═╝ ╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝
# Structura pro Resultatibus Benchmark

@dataclass
class BenchmarkResult:
    """Dataclass pro conservatione resultatorum unius test."""
    test_name: str
    score: float
    unit: str
    duration_sec: float
    metrics: Dict[str, Any] = field(default_factory=dict) # Metricas additionales (e.g., potentia, temp)

    def to_dict(self) -> Dict[str, Any]:
        """Convertit resultatum ad dictionarium pro serializatione."""
        return asdict(self)

#  █████╗ ███████╗ ██████╗ ███████╗ █████╗ ██████╗ ███████╗███████╗
# ██╔══██╗██╔════╝██╔════╝ ██╔════╝██╔══██╗██╔══██╗██╔════╝██╔════╝
# ███████║███████╗██║  ███╗███████╗███████║██████╔╝███████╗███████╗
# ██╔══██║╚════██║██║   ██║╚════██║██╔══██║██╔══██╗╚════██║╚════██║
# ██║  ██║███████║╚██████╔╝███████║██║  ██║██║  ██║███████║███████║
# ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝
# Nucleus Benchmark Adaptivus

class AdaptiveBenchmark:
    """
    Orchestrat executionem testium benchmark, colligit resultatus,
    et adaptat se ad conditiones systematis.
    """
    def __init__(self, thermal_limit: float = 85.0, result_queue: Optional[queue.Queue] = None):
        """
        Initializat benchmark.
        :param thermal_limit: Maxima temperatura CPU admittenda (Celsius).
        :param result_queue: Optional: Queue pro communicatione inter fila.
        """
        self.probe = UniversalSystemProbe() # Utitur singleton instance
        self.optimizer = NeuralOptimizer(input_size=4, hidden_size=6) # Input size = 4 (cpu, mem, disk, temp)
        self.thermal_limit = thermal_limit
        self.results: Dict[str, BenchmarkResult] = {}
        self.result_queue = result_queue if result_queue else queue.Queue()
        self._stop_event = threading.Event() # Pro terminatione gratiosa monitoris

    def _log(self, message: str):
        """Simplex functio logging ad queue vel stdout."""
        log_msg = f"[{time.strftime('%H:%M:%S')}] {message}"
        if self.result_queue:
            self.result_queue.put({'type': 'log', 'message': log_msg})
        else:
            print(log_msg)

    def _thermal_monitor(self):
        """Monitorizat temperaturam in filo separato et pausat si nimis calidum est."""
        self._log("Monitor thermalis initiatus.")
        while not self._stop_event.is_set():
            current_temp = self.probe.get_cpu_temperature()
            # self._log(f"Temperatura actualis: {current_temp}°C") # Verbose logging
            if current_temp > self.thermal_limit:
                self._log(f"⚠️ Limen thermale ({self.thermal_limit}°C) superatum ({current_temp}°C). Pausando...")
                while current_temp > self.thermal_limit - 5 and not self._stop_event.is_set(): # Refrigeratio ad limen - 5
                    time.sleep(3)
                    current_temp = self.probe.get_cpu_temperature()
                if not self._stop_event.is_set():
                    self._log(f"✅ Temperatura stabilizata ({current_temp}°C). Resumendo...")
            time.sleep(5) # Frequentia check
        self._log("Monitor thermalis terminatus.")

    def _run_single_test(self, test_func, name: str, *args, **kwargs) -> Optional[BenchmarkResult]:
        """Invólucrum pro executione unius test cum mensura temporis et error handling."""
        self._log(f"Incipiendo test: {name}...")
        start_time = time.perf_counter()
        start_temp = self.probe.get_cpu_temperature()
        start_power = self.probe.get_power_consumption()
        result_value = None
        unit = "N/A"
        error = None

        try:
            result_value, unit = test_func(*args, **kwargs) # Functio test debet reddere (valorem, unitatem)
        except Exception as e:
            error = str(e)
            self._log(f"❌ Error in test {name}: {e}")

        end_time = time.perf_counter()
        end_temp = self.probe.get_cpu_temperature()
        end_power = self.probe.get_power_consumption()
        duration = end_time - start_time

        if error:
             # Potest creare resultatum erroris specificum
             return None

        if result_value is not None:
            result = BenchmarkResult(
                test_name=name,
                score=round(result_value, 2) if isinstance(result_value, float) else result_value,
                unit=unit,
                duration_sec=round(duration, 3),
                metrics={
                    'temp_start_c': start_temp,
                    'temp_end_c': end_temp,
                    'power_start_w': start_power,
                    'power_end_w': end_power,
                    'avg_temp_c': round((start_temp + end_temp) / 2, 1),
                    'avg_power_w': round((start_power + end_power) / 2, 2),
                }
            )
            self._log(f"✅ Test {name} completus: Score={result.score} {result.unit}, Duration={result.duration_sec}s")
            if self.result_queue:
                 self.result_queue.put({'type': 'result', 'data': result.to_dict()})
            return result
        return None

    # --- Test Functiones Specifica ---

    def _cpu_math_test(self, iterations: int = 2 * 10**6) -> Tuple[float, str]:
        """Test intensivum CPU: Operationes mathematicae mixtae."""
        # Iterationes adaptari possunt secundum potentiam CPU initialem
        x = random.random() + 0.1 # Valor initialis non-nullus
        for i in range(int(iterations)):
            # Mixtura operationum: log, exp, trigonometricae, radices
            x = math.log(math.fabs(math.sin(x)**2 + math.cos(i/1e5)**2) + 1e-9) # Evitat log(0)
            x = math.exp(math.sqrt(math.fabs(x))) / (i + 1)
            if i % 10000 == 0: # Prevenit valores nimis magnos/parvos
                 x = (x % 1000) + 0.1
        # Score est operationes per secundam (kOps/s)
        # Hoc est placeholder; calculus realis operationum est complexior
        ops_per_sec = iterations / (time.perf_counter() - (start_time := time.perf_counter()))
        return ops_per_sec / 1000, "kOps/s"

    def _memory_throughput_test(self, size_mb: int = 150) -> Tuple[float, str]:
        """Test bandae memoriae: Creatio, accessus, et hashing magni bufferis."""
        data = bytearray(1024 * 1024 * size_mb)
        # Scriptio initialis (potest esse pars mensurae)
        for i in range(len(data)):
            data[i] = i % 256

        start_time = time.perf_counter()
        # Lectio / Processus (hashing ut exemplum)
        _ = hashlib.sha256(data).hexdigest()
        duration = time.perf_counter() - start_time
        throughput_mbs = size_mb / duration
        return throughput_mbs, "MB/s"

    def _disk_io_test(self, filename: str = "temp_benchmark_disk.dat", size_mb: int = 50, block_size_kb: int = 128) -> Tuple[float, str]:
        """Test I/O disci: Scriptio et lectio fasciculi temporarii."""
        data_block = os.urandom(block_size_kb * 1024)
        num_blocks = (size_mb * 1024) // block_size_kb
        total_written = 0
        total_read = 0

        try:
            # --- Scriptio Test ---
            write_start = time.perf_counter()
            with open(filename, 'wb') as f:
                for _ in range(num_blocks):
                    written = f.write(data_block)
                    total_written += written
            # Assecurat omnia scripta esse ad discum physicum
            if hasattr(os, 'fsync'):
                 with open(filename, 'rb') as f: # Reopen in read mode for fsync if needed
                     os.fsync(f.fileno())
            write_duration = time.perf_counter() - write_start
            write_speed_mbs = (total_written / (1024**2)) / write_duration if write_duration > 0 else 0

            # --- Lectio Test ---
            read_start = time.perf_counter()
            with open(filename, 'rb') as f:
                while True:
                    read_data = f.read(block_size_kb * 1024)
                    if not read_data:
                        break
                    total_read += len(read_data)
            read_duration = time.perf_counter() - read_start
            read_speed_mbs = (total_read / (1024**2)) / read_duration if read_duration > 0 else 0

        finally:
            # Purgatio fasciculi temporarii
            if os.path.exists(filename):
                os.remove(filename)

        # Potest reddere mediocrem, scriptionem, vel lectionem specificam
        # Hic reddimus mediocrem harmonicam pro score combinato
        if write_speed_mbs > 0 and read_speed_mbs > 0:
             combined_speed = 2 / (1/write_speed_mbs + 1/read_speed_mbs)
        elif write_speed_mbs > 0:
             combined_speed = write_speed_mbs
        elif read_speed_mbs > 0:
             combined_speed = read_speed_mbs
        else:
             combined_speed = 0

        return combined_speed, "MB/s (Avg I/O)"


    def run_all_benchmarks(self) -> Dict[str, BenchmarkResult]:
        """Executat omnes testes definitos et colligit resultatus."""
        self._log("🚀 Incipiendo seriem benchmark universalem...")
        self.results = {}
        monitor_thread = None

        try:
            # Initium monitoris thermalis in filo separato
            self._stop_event.clear()
            monitor_thread = threading.Thread(target=self._thermal_monitor, daemon=True)
            monitor_thread.start()
            time.sleep(1) # Dat tempus monitori initializari

            # --- Executio Testium ---
            tests_to_run = [
                (self._cpu_math_test, "CPU_Math", 2 * 10**6), # Iterationes possunt adaptari
                (self._memory_throughput_test, "Memory_Throughput", 150), # Magnitudo MB potest adaptari
                (self._disk_io_test, "Disk_IO", "temp_bench.dat", 50, 128), # Nomen, Magnitudo MB, Block KB
                # Addere plures testes hic...
                # (self._cpu_crypto_test, "CPU_Crypto", 10**5),
                # (self._latency_test, "Network_Latency", "google.com"),
            ]

            for test_func, name, *args in tests_to_run:
                 # Pausa brevis inter testes ad permittendum systema stabilizari
                 time.sleep(1.5)
                 result = self._run_single_test(test_func, name, *args)
                 if result:
                     self.results[name] = result

            # --- Calculatio Score AI (Post testes) ---
            self._log("🧠 Calculando score optimizationis AI...")
            if 'CPU_Math' in self.results and 'Memory_Throughput' in self.results and 'Disk_IO' in self.results:
                inputs = [
                    self.results['CPU_Math'].score / 100, # Normalizare inputa
                    self.results['Memory_Throughput'].score / 100,
                    self.results['Disk_IO'].score / 50,
                    self.probe.get_cpu_temperature() / 100 # Addit temperaturam actualem
                ]
                ai_score_raw = self.optimizer.predict(inputs)
                # Optional: Disciplina simplex (si data historica vel target essent)
                # target_score = 0.8 # Exemplum target
                # self.optimizer.train_step(inputs, target_score)
                # self._log(f"Staus optimizer post disciplinam: {self.optimizer.get_status()}")

                ai_result = BenchmarkResult(
                    test_name="AI_Optimization_Score",
                    score=round(ai_score_raw * 100, 1), # Convertit ad percentage
                    unit="%",
                    duration_sec=0.0, # Calculatio est instantanea
                    metrics={'optimizer_status': self.optimizer.get_status()}
                )
                self.results["AI_Score"] = ai_result
                if self.result_queue:
                    self.result_queue.put({'type': 'result', 'data': ai_result.to_dict()})
                self._log(f"💡 Score AI calculatus: {ai_result.score}%")
            else:
                self._log("⚠️ Non satis resultatorum pro calculatione score AI.")

        except Exception as e:
            self._log(f"❌ Error fatalis in executione benchmark: {e}")
        finally:
            # Terminatio monitoris thermalis
            self._stop_event.set()
            if monitor_thread and monitor_thread.is_alive():
                monitor_thread.join(timeout=5) # Exspectat terminationem monitoris
            self._log("🏁 Series benchmark completa.")
            if self.result_queue:
                 self.result_queue.put({'type': 'status', 'message': 'completed'})

        return self.results

# ███████╗ ██████╗ ██████╗ ██╗   ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔════╝ ██║   ██║██╔════╝██╔════╝
# ███████╗██║     ██║  ███╗██║   ██║███████╗███████╗
# ╚════██║██║     ██║   ██║██║   ██║╚════██║╚════██║
# ███████║╚██████╗╚██████╔╝╚██████╔╝███████║███████║
# ╚══════╝ ╚═════╝ ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
# Functio principalis et executio

def display_results(results: Dict[str, BenchmarkResult], system_info: Dict[str, Any]):
    """Formatat et monstrat resultatus benchmark et informationem systematis."""
    print("\n" + "="*60)
    print("       SYSTEMA INFORMATIO (Explorator Universalis)")
    print("-"*60)
    for key, value in system_info.items():
        print(f"  {key.replace('_', ' ').capitalize():<20}: {value if value is not None else 'N/A'}")

    disk_info = UniversalSystemProbe().get_disk_usage() # Re-probe pro info actuali disci
    if disk_info:
        print(f"  {'Disk total (GB)':<20}: {disk_info[0]}")
        print(f"  {'Disk available (GB)':<20}: {disk_info[1]}")
    print("="*60)

    print("\n" + "="*60)
    print("         AMPLIUS BENCHMARK RESULTATUS")
    print("-"*60)
    print(f"{'Test Nomen':<25} | {'Score':>10} | {'Unitas':<15} | {'Duratio (s)':>12}")
    print("-"*60)

    sorted_keys = sorted(results.keys(), key=lambda x: (x != 'AI_Score', x)) # AI Score ad finem

    for key in sorted_keys:
        res = results[key]
        print(f"{res.test_name:<25} | {res.score:>10} | {res.unit:<15} | {res.duration_sec:>12.3f}")

    print("-"*60)

    # Monstrat metricas additionales (temperatura, potentia) pro testibus selectis
    print("\n  Metricas Additionales (Avg Temp/Potentia):")
    for key in ['CPU_Math', 'Memory_Throughput', 'Disk_IO']:
        if key in results:
            metrics = results[key].metrics
            avg_temp = metrics.get('avg_temp_c', 'N/A')
            avg_power = metrics.get('avg_power_w', 'N/A')
            print(f"    {key:<20}: Temp={avg_temp}°C, Potentia={avg_power}W")

    print("="*60)


if __name__ == "__main__":
    # --- Configuratio ---
    output_filename = "amplius_benchmark_results.desf" # Nomen fasciculi output encrypti
    encryption_key_seed = platform.node() + platform.processor() # Clavis derivata ex info systematis

    # --- Initializatio ---
    probe = UniversalSystemProbe() # Initializat (vel accipit) singleton instance
    system_info = probe.get_system_info()

    benchmark_suite = AdaptiveBenchmark(thermal_limit=80.0) # Limen thermale configurabile
    encoder = QuantumSafeEncoder(key_seed=encryption_key_seed)

    # --- Executio ---
    final_results = benchmark_suite.run_all_benchmarks()

    # --- Salvatio Resultatorum ---
    if final_results:
        results_to_save = {
            'metadata': {
                'timestamp': time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
                'benchmark_version': '2.0',
                'system_info': system_info
            },
            'results': {k: v.to_dict() for k, v in final_results.items()}
        }
        encoder.save_encrypted(results_to_save, output_filename)
        print(f"\n🔒 Resultatus encrypti salvati in: {output_filename}")

        # --- Monstratio Resultatorum ---
        display_results(final_results, system_info)

        # --- Exemplum lectionis resultatorum decryptorum ---
        # print("\n--- Tentamen Lectionis Resultatorum Decryptorum ---")
        # loaded_results = encoder.load_decrypted(output_filename)
        # if loaded_results:
        #     print("Resultatus decrypti et onerati feliciter.")
        #     # print(json.dumps(loaded_results, indent=2)) # Monstrat contentum si necesse est
        # else:
        #     print("Error onerando resultatus decryptos.")

    else:
        print("\n❌ Benchmark non potuit compleri vel nullos resultatus generavit.")

    print("\n✨ Executio completa.")

