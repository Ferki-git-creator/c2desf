/**
 * @file parser.h
 * @brief DESF format parser with error handling, plugin support, asynchronous processing,
 * SIMD acceleration and a modular driver     * interface.
 * @author Ferki
 * @license MIT
 *
 * 🚀 Cross-platform • Ultra-lightweight • Streaming API • Modular Drivers • SIMD & Async
 */

 #pragma once

 #include "commands.h"
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 
 #ifdef __cplusplus
 extern "C" {
 #endif
 
 //=================================================================
 //                           Configuration
 //=================================================================
 
 // Maximum nested loop depth for validation.
 #define MAX_LOOP_DEPTH 32
 
 // Parser error codes (bitmask).
 typedef enum {
     PARSE_OK             = 0,
     PARSE_ERR_IO         = 1 << 0,
     PARSE_ERR_SYNTAX     = 1 << 1,
     PARSE_ERR_OVERFLOW   = 1 << 2,
     PARSE_ERR_LOOP_DEPTH = 1 << 3,
     PARSE_ERR_PLUGIN     = 1 << 4
 } ParseError;
 
 //=================================================================
 //                     Streaming Parser API
 //=================================================================
 
 /**
  * @struct DesfParserContext
  * @brief Stateful parser context for streaming processing.
  */
 typedef struct {
     DesfCommand *command_buf;   ///< Pre-allocated command buffer.
     size_t buf_size;            ///< Total buffer capacity.
     size_t cmd_count;           ///< Current number of parsed commands.
 
     struct {
         int loop_depth;         ///< Current loop nesting depth.
         uint32_t error_flags;   ///< Bitmask of ParseError codes.
     } state;
 } DesfParserContext;
 
 /**
  * @brief Initialize the parser with a pre-allocated buffer.
  * @param ctx Parser context.
  * @param buf Command buffer (must persist).
  * @param buf_size Buffer capacity in commands.
  *
  * @note Buffer must outlive the parser.
  */
 void desf_parser_init(DesfParserContext *ctx,
                       DesfCommand *buf,
                       size_t buf_size);
 
 /**
  * @brief Parse a chunk of .desf data.
  * @param ctx Parser context.
  * @param data Input data chunk.
  * @param len Chunk length in bytes.
  * @return Number of bytes processed.
  *
  * @warning Partial commands are buffered internally.
  */
 size_t desf_parser_feed(DesfParserContext *ctx,
                         const char *data,
                         size_t len);
 
 /**
  * @brief Finalize parsing and validate the command sequence.
  * @param ctx Parser context.
  * @return 0 on success, error bitmask on failure.
  */
 uint32_t desf_parser_finalize(DesfParserContext *ctx);
 
 //=================================================================
 //                     File-based Parsing
 //=================================================================
 
 /**
  * @brief Parse an entire .desf file into memory.
  * @param filename Input file path.
  * @param[out] program Resulting command array.
  * @param[out] count Number of parsed commands.
  * @return 0 on success, ParseError code on failure.
  *
  * @note Uses malloc() for buffer allocation.
  */
 int desf_parse_file(const char *filename,
                     DesfCommand **program,
                     size_t *count);
 
 //=================================================================
 //                     Plugin Integration API
 //=================================================================
 
 /// Parser plugin hook type.
 typedef int (*DesfParseHook)(DesfParserContext*, const char*);
 
 /**
  * @brief Register a custom syntax extension.
  * @param directive Directive prefix (e.g., "!!crypto").
  * @param handler Handler function.
  *
  * @example Register YAML frontmatter parser:
  * desf_register_extension("---", &yaml_parser);
  */
 void desf_register_extension(const char *directive,
                              DesfParseHook handler);
 
 //=================================================================
 //                     Asynchronous Parsing (Optional)
 //=================================================================
 
 // Enable asynchronous parsing by defining DESF_ENABLE_ASYNC in your build.
 #ifdef DESF_ENABLE_ASYNC
 #include <pthread.h>
 
 typedef struct {
     DesfParserContext *ctx;
     const char *data;
     size_t len;
 } AsyncFeedArgs;
 
 /**
  * @brief Thread function for asynchronous feed processing.
  * @param arg Pointer to AsyncFeedArgs.
  * @return NULL.
  */
 static void* async_feed_thread(void* arg) {
     AsyncFeedArgs *args = (AsyncFeedArgs*) arg;
     desf_parser_feed(args->ctx, args->data, args->len);
     free(args);
     return NULL;
 }
 
 /**
  * @brief Asynchronously feed data into the parser.
  * @param ctx Parser context.
  * @param data Input data chunk.
  * @param len Chunk length in bytes.
  *
  * This function spawns a detached thread to process the data.
  */
 static inline void desf_parser_feed_async(DesfParserContext *ctx,
                                            const char *data,
                                            size_t len) {
     AsyncFeedArgs *args = malloc(sizeof(AsyncFeedArgs));
     if (!args) return; // Allocation failure; consider error handling.
     args->ctx = ctx;
     args->data = data;
     args->len = len;
     
     pthread_t thread;
     pthread_create(&thread, NULL, async_feed_thread, args);
     pthread_detach(thread);
 }
 #endif
 
 //=================================================================
 //                     Low-Level Operations & SIMD Support
 //=================================================================
 
 #ifdef __SSE2__
 #include <emmintrin.h>
 /**
  * @brief SIMD-accelerated XOR encryption for a command structure.
  * @param cmd Pointer to the command structure.
  * @param key Encryption key (32 bytes).
  *
  * Uses SSE2 instructions to process blocks of 16 bytes.
  */
 static inline void desf_xor_encrypt_simd(DesfCommand *cmd, const uint8_t key[32]) {
     uint8_t *data = (uint8_t*) cmd;
     size_t data_len = sizeof(DesfCommand);
     size_t i = 0;
     __m128i key_chunk = _mm_loadu_si128((const __m128i*) key);
     for (; i + 15 < data_len; i += 16) {
         __m128i block = _mm_loadu_si128((const __m128i*)(data + i));
         block = _mm_xor_si128(block, key_chunk);
         _mm_storeu_si128((__m128i*)(data + i), block);
     }
     for (; i < data_len; i++) {
         data[i] ^= key[i % 32];
     }
 }
 #endif
 
 /**
  * @brief Default XOR encryption for a command structure.
  * @param cmd Pointer to the command structure.
  * @param key Encryption key (32 bytes).
  */
 static inline void desf_xor_encrypt(DesfCommand *cmd, const uint8_t key[32]) {
 #ifdef __SSE2__
     desf_xor_encrypt_simd(cmd, key);
 #else
     uint8_t *data = (uint8_t*) cmd;
     size_t data_len = sizeof(DesfCommand);
     for (size_t i = 0; i < data_len; i++) {
         data[i] ^= key[i % 32];
     }
 #endif
 }
 
 #ifdef DESF_ENCRYPTION
 /**
  * @brief Macro for command encryption.
  */
 #define DESF_ENCRYPT(cmd, key) desf_xor_encrypt((cmd), (key))
 #endif
 
 //=================================================================
 //                     Modular Driver Interface
 //=================================================================
 
 /**
  * @struct DesfDriver
  * @brief Structure representing a mini driver for platform-specific operations.
  */
 typedef struct DesfDriver {
     const char *name;                         ///< Driver name.
     int (*init)(void);                        ///< Initialization function.
     int (*shutdown)(void);                    ///< Shutdown/cleanup function.
     int (*execute)(const DesfCommand *cmd);   ///< Execute driver-specific command.
     struct DesfDriver *next;                  ///< Pointer to the next driver in the chain.
 } DesfDriver;
 
 /**
  * @brief Register a mini driver.
  * @param driver Pointer to the driver structure.
  *
  * Allows dynamic registration of platform-specific mini drivers.
  */
 void desf_register_driver(DesfDriver *driver);
 
 /**
  * @brief Retrieve a registered driver by name.
  * @param name Driver name.
  * @return Pointer to the registered driver, or NULL if not found.
  */
 DesfDriver* desf_get_driver(const char *name);
 
 /**
  * @brief Initialize all registered drivers.
  * @return 0 on success, or an error code.
  */
 int desf_initialize_drivers(void);
 
 /**
  * @brief Shutdown all registered drivers.
  */
 void desf_shutdown_drivers(void);
 
 //=================================================================
 
 #ifdef __cplusplus
 }
 #endif
 
 // End of parser.h
 