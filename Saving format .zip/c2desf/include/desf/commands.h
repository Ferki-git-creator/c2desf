/**
 * @file command.h
 * @brief DESF (Device-Embedded Stream Format) command definitions
 * @authorFerki
 * @license MIT
 *
 * 🚀 Cross-platform • Ultra-lightweight • Quantum-Resistant 🛡️
 */

 #pragma once

 #include <stdint.h>
 #include <stddef.h>
 #include <string.h>
 
 #ifdef __cplusplus
 extern "C" {
 #endif
 
 //═════════════════════════════════════════════════════════════════════════════
 //                              Configuration
 //═════════════════════════════════════════════════════════════════════════════
 
 #ifndef DESF_STANDALONE
     /// @brief Enable minimal stdio implementation for embedded systems
     #define DESF_STANDALONE 1
 #endif
 
 #ifndef DESF_ENCRYPTION
     /// @brief Enable XOR-based command encryption (for anti-tampering)
     #define DESF_ENCRYPTION 1
 #endif
 
 //═════════════════════════════════════════════════════════════════════════════
 //                             Core Structures
 //═════════════════════════════════════════════════════════════════════════════
 
 /**
  * @enum DesfCommandType
  * @brief DESF command types with Unicode aliases
  *
  * @note Arithmetic: ADD (➕), SUB (➖), MUL (✖️), DIV (➗)
  * @note Control Flow: JUMP_IF_GT (▶️)
  */
 typedef enum {
     DESF_CMD_SET,           ///< SET @var = value
     DESF_CMD_ADD,           ///< ADD @dest @a @b
     DESF_CMD_SUB,           ///< SUB @dest @a @b
     DESF_CMD_MUL,           ///< MUL @dest @a @b
     DESF_CMD_DIV,           ///< DIV @dest @a @b
     DESF_CMD_JUMP_IF_GT,    ///< JUMP if @a > @b
     DESF_CMD_LOOP,          ///< LOOP @var from @start to @end
     DESF_CMD_DEBUG_BREAK    ///< Debugger breakpoint
 } DesfCommandType;
 
 /**
  * @struct DesfCommand
  * @brief Unified command structure with operand union
  */
 typedef struct {
     DesfCommandType type;   ///< Command type
     union {
         struct {
             char op1[32];   ///< Primary operand (e.g., "@var")
             char op2[32];   ///< Secondary operand (e.g., "42")
             char op3[32];   ///< Tertiary operand (e.g., "10")
         } operands;
         char label[64];      ///< Jump target label (e.g., "loop_start")
     } data;
 } DesfCommand;
 
 //═════════════════════════════════════════════════════════════════════════════
 //                     Developer-Friendly Inline Functions
 //═════════════════════════════════════════════════════════════════════════════
 
 /**
  * @brief Create a loop command.
  * @param var Loop variable name.
  * @param start Start value.
  * @param end End value.
  * @param step Step value.
  * @return DesfCommand structure representing the loop command.
  */
 static inline DesfCommand create_loop_command(const char *var, const char *start, const char *end, const char *step) {
     DesfCommand cmd;
     cmd.type = DESF_CMD_LOOP;
     strncpy(cmd.data.operands.op1, var, sizeof(cmd.data.operands.op1));
     strncpy(cmd.data.operands.op2, start, sizeof(cmd.data.operands.op2));
     strncpy(cmd.data.operands.op3, end, sizeof(cmd.data.operands.op3));
     strncpy(cmd.data.label, step, sizeof(cmd.data.label));
     return cmd;
 }
 
 /**
  * @brief Create an addition command.
  * @param dest Destination variable name.
  * @param a First operand.
  * @param b Second operand.
  * @return DesfCommand structure representing the addition command.
  */
 static inline DesfCommand create_add_command(const char *dest, const char *a, const char *b) {
     DesfCommand cmd;
     cmd.type = DESF_CMD_ADD;
     strncpy(cmd.data.operands.op1, dest, sizeof(cmd.data.operands.op1));
     strncpy(cmd.data.operands.op2, a, sizeof(cmd.data.operands.op2));
     strncpy(cmd.data.operands.op3, b, sizeof(cmd.data.operands.op3));
     return cmd;
 }
 
 #if DESF_ENCRYPTION
 /**
  * @brief XOR-encrypt a command using a 256-bit key.
  * @param cmd Pointer to the command structure to encrypt.
  * @param key Encryption key (32 bytes).
  */
 static inline void desf_xor_encrypt(DesfCommand *cmd, const uint8_t key[32]) {
     uint8_t *data = (uint8_t*) cmd;
     size_t data_len = sizeof(DesfCommand);
     for (size_t i = 0; i < data_len; i++) {
         data[i] ^= key[i % 32];
     }
 }
 
 /**
  * @brief Macro for command encryption.
  */
 #define DESF_ENCRYPT(cmd, key) desf_xor_encrypt((cmd), (key))
 #endif
 
 //═════════════════════════════════════════════════════════════════════════════
 //                      Embedded I/O Implementation
 //═════════════════════════════════════════════════════════════════════════════
 
 #if DESF_STANDALONE
 /**
  * @brief Minimal printf implementation for embedded targets.
  * @param format Format string (supports %d, %s, %c).
  */
 void desf_printf(const char* format, ...);
 #endif
 
 //═════════════════════════════════════════════════════════════════════════════
 //                           Advanced Features
 //═════════════════════════════════════════════════════════════════════════════
 
 /**
  * @brief Plugin handler type for DESF extensions.
  */
 typedef void (*DesfPluginHandler)(DesfCommand*);
 
 /**
  * @brief Register an external plugin for DESF extension.
  * @param name Plugin identifier (e.g., "crypto", "network").
  * @param handler Callback function for custom commands.
  */
 void desf_register_plugin(const char* name, DesfPluginHandler handler);
 
 /**
  * @brief Validate the integrity of a command sequence.
  * @param program Array of DesfCommand structures.
  * @param length Number of commands in the program.
  * @return 0 if valid, error code if issues are found.
  *
  * @note Error Codes:
  *   1: Invalid command type
  *   2: Operand overflow
  *   3: Loop depth exceeded
  */
 int desf_validate(const DesfCommand* program, size_t length);
 
 #ifdef __cplusplus
 }
 #endif
 