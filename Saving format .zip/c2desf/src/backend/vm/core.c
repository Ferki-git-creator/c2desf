/**
 * @file core.c
 * @brief DESF Virtual Machine Core Implementation (Extended Version)
 * @author Your Name (Based on Ferki's vm.h)
 * @license MIT
 *
 * @details This file implements the core logic for the DESF virtual machine,
 * including initialization, execution loop, memory access, device mapping,
 * and plugin loading, based on the definitions in desf/vm.h.
 * This extended version includes more instructions, basic addressing modes,
 * improved error handling, debugging hooks, and more detailed placeholders
 * for advanced features.
 */

#include "desf/vm.h"      // Main header with VM definitions
#include <stdlib.h>     // For malloc, free, NULL, exit
#include <string.h>     // For memcpy, memset
#include <stdio.h>      // For basic error reporting/logging
#include <stdbool.h>    // For bool type
#include <stdint.h>     // For standard integer types

// Assume DesfCommand structure is defined in "desf/commands.h"
// We'll assume it includes fields like: type, operand1, operand2, operand3, flags/mode
/*
typedef enum { ... } DesfCommandType; // Defined in commands.h
typedef struct {
    DesfCommandType type;
    int32_t operand1; // Can be register, immediate, address
    int32_t operand2; // Can be register, immediate, address
    int32_t operand3; // Can be register, immediate, address
    uint8_t mode;     // Flags for addressing modes, operand types etc.
} DesfCommand;

// Example mode flags (define properly based on instruction set design)
#define MODE_OP1_REG      (1 << 0)
#define MODE_OP1_IMM      (1 << 1)
#define MODE_OP1_MEM_ADDR (1 << 2) // Operand is a direct memory address
#define MODE_OP1_MEM_REG  (1 << 3) // Operand is register containing memory address
// Similar flags for OP2, OP3
*/

// Placeholder for Plugin Handler type (should be defined properly)
// Assuming it takes VM context and a reason code (e.g., init, shutdown, call)
typedef int (*DesfPluginHandler)(DesfVirtualMachine *vm, uint32_t reason, void* data);
#define PLUGIN_REASON_INIT      1
#define PLUGIN_REASON_SHUTDOWN  2
#define PLUGIN_REASON_CALL      3 // Example for calling plugin functions

//==========================================================
//           Architecture Detection & Optimizations
//==========================================================
// (Same as previous version - AVX/NEON detection)
#if defined(__x86_64__) || defined(_M_X64)
    #define DESF_ARCH_X86_64
    #if defined(__AVX2__)
        #define DESF_HAS_AVX2
        #include <immintrin.h>
    #endif
    #if defined(__AVX512F__)
        #define DESF_HAS_AVX512
        #include <immintrin.h>
    #endif
#elif defined(__aarch64__)
    #define DESF_ARCH_ARM64
    #if defined(__ARM_NEON)
        #define DESF_HAS_NEON
        #include <arm_neon.h>
    #endif
#elif defined(__arm__)
    #define DESF_ARCH_ARM32
    #if defined(__ARM_NEON)
        #define DESF_HAS_NEON
        #include <arm_neon.h>
    #endif
#else
    #define DESF_ARCH_GENERIC
#endif

// Compiler specific attributes
#if defined(__GNUC__) || defined(__clang__)
    #define DESF_LIKELY(x)       __builtin_expect(!!(x), 1)
    #define DESF_UNLIKELY(x)     __builtin_expect(!!(x), 0)
    #define DESF_UNUSED          __attribute__((unused))
    #define DESF_ALWAYS_INLINE   inline __attribute__((always_inline))
    #define DESF_NOINLINE        __attribute__((noinline))
    #define DESF_PACKED          __attribute__((packed))
#else
    #define DESF_LIKELY(x)       (x)
    #define DESF_UNLIKELY(x)     (x)
    #define DESF_UNUSED
    #define DESF_ALWAYS_INLINE   inline // Or __forceinline for MSVC
    #define DESF_NOINLINE
    #define DESF_PACKED          // May need #pragma pack for MSVC
#endif

// Debug Logging Configuration
// #define DESF_ENABLE_DEBUG_LOG // Uncomment to enable debug messages

#ifdef DESF_ENABLE_DEBUG_LOG
    #define DEBUG_LOG(fmt, ...) \
        fprintf(stderr, "[DESF Debug PC=0x%04X] " fmt "\n", vm->state.pc, ##__VA_ARGS__)
#else
    #define DEBUG_LOG(fmt, ...) ((void)0) // Disable logging
#endif

//==========================================================
//                  Internal Constants & Enums
//==========================================================
#define STACK_REG_INDEX     (DESF_MAX_REGISTERS - 1) // R15 is SP
#define STACK_START_ADDRESS (DESF_MEM_SIZE)         // Stack grows downwards from top (exclusive)
#define STACK_MIN_ADDRESS   (DESF_MEM_SIZE / 2)     // Arbitrary lower limit for stack

// Addressing modes (simplified example, expand as needed)
typedef enum {
    ADDR_MODE_IMMEDIATE,    // Operand is the value itself
    ADDR_MODE_REGISTER,     // Operand is a register index
    ADDR_MODE_MEM_DIRECT,   // Operand is a direct memory address
    ADDR_MODE_MEM_REG_INDIRECT // Operand is register containing memory address
    // Add more: [Reg+Offset], [Reg+Reg], etc.
} AddressingMode;

//==========================================================
//                  Error Handling
//==========================================================
// Error codes (expand as needed)
typedef enum {
    VM_ERR_OK = 0,
    VM_ERR_HALTED = 1, // Normal halt, not really an error
    VM_ERR_UNKNOWN = -1,
    VM_ERR_OUT_OF_BOUNDS = -2,
    VM_ERR_INVALID_OPCODE = -3,
    VM_ERR_INVALID_OPERAND = -4,
    VM_ERR_INVALID_ADDR_MODE = -5,
    VM_ERR_STACK_OVERFLOW = -6,
    VM_ERR_STACK_UNDERFLOW = -7,
    VM_ERR_DEVICE_MAP_FAILED = -8,
    VM_ERR_PLUGIN_LOAD_FAILED = -9,
    VM_ERR_DIV_BY_ZERO = -10,
    VM_ERR_INVALID_DEVICE_OP = -11,
    VM_ERR_JIT_FAILURE = -12,
    VM_ERR_CACHE_FAILURE = -13,
    VM_ERR_UNALIGNED_ACCESS = -14,
    VM_ERR_PLUGIN_CALL_FAILED = -15,
    VM_ERR_SYSCALL_FAILED = -16,
} VMErrorCode;

// Error reporting macro
#define VM_ERROR_LOG(vm, code, message) \
    do { \
        fprintf(stderr, "DESF VM Error (PC=0x%04X): %s (%d)\n", (vm)->state.pc, message, code); \
        (vm)->state.status_flags |= DESF_STATUS_ERROR | DESF_STATUS_HALT; \
    } while (0)

//==========================================================
//          Forward Declarations of Internal Helpers
//==========================================================

// Memory & Device Access
static bool _is_address_valid(uint32_t address, size_t size);
static int _handle_memory_access(DesfVirtualMachine *vm, uint32_t address, uint8_t *buffer, size_t size, bool is_write);
static int32_t _read_memory(DesfVirtualMachine *vm, uint32_t address, size_t size, VMErrorCode *error);
static VMErrorCode _write_memory(DesfVirtualMachine *vm, uint32_t address, int32_t value, size_t size);

// Flag Updates
static void _update_zero_flag(DesfVirtualMachine *vm, int32_t result);
static void _update_carry_flag_add(DesfVirtualMachine *vm, uint32_t a, uint32_t b);
static void _update_carry_flag_sub(DesfVirtualMachine *vm, uint32_t a, uint32_t b);
static void _update_overflow_flag_add(DesfVirtualMachine *vm, int32_t a, int32_t b, int32_t result); // Signed overflow
static void _update_overflow_flag_sub(DesfVirtualMachine *vm, int32_t a, int32_t b, int32_t result); // Signed overflow
// Add more flag helpers if needed (e.g., Parity, Sign)

// Stack Operations
static VMErrorCode _push_stack(DesfVirtualMachine *vm, int32_t value);
static int32_t _pop_stack(DesfVirtualMachine *vm, VMErrorCode *error);

// Operand Decoding & Addressing Modes
static int32_t _get_operand_value(DesfVirtualMachine *vm, int32_t operand_spec, AddressingMode mode, VMErrorCode *error);
static uint32_t _get_operand_address(DesfVirtualMachine *vm, int32_t operand_spec, AddressingMode mode, VMErrorCode *error);
// Add more specific decoding helpers if command structure is complex

// Instruction Execution
static void _execute_instruction(DesfVirtualMachine *vm, const DesfCommand *cmd);
static void _handle_unknown_opcode(DesfVirtualMachine *vm, const DesfCommand *cmd);

// System Call Handling
static void _handle_syscall(DesfVirtualMachine *vm, int32_t call_num);

// JIT / Cache Placeholders
static void _jit_init(DesfVirtualMachine *vm);
static void _jit_shutdown(DesfVirtualMachine *vm);
static void _jit_compile_block(DesfVirtualMachine *vm, uint32_t start_pc);
static bool _jit_execute_block(DesfVirtualMachine *vm); // Returns true if JIT handled execution
static void _cache_init(DesfVirtualMachine *vm);
static void _cache_shutdown(DesfVirtualMachine *vm);
static uint8_t* _cache_lookup(DesfVirtualMachine *vm, uint32_t address, size_t size);
static void _cache_write(DesfVirtualMachine *vm, uint32_t address, const uint8_t* data, size_t size);
static void _cache_invalidate(DesfVirtualMachine *vm, uint32_t address, size_t size);

// Misc Helpers
static void _vectorized_memcpy(void* dest, const void* src, size_t size);
static void _dump_registers(const DesfVirtualMachine *vm); // Debug helper

//==========================================================
//                 Public API Implementation
//==========================================================

/**
 * @brief Initialize virtual machine state.
 */
void desf_vm_init(DesfVirtualMachine *vm, const uint8_t *init_mem) {
    if (!vm) {
        fprintf(stderr, "Fatal Error: Cannot initialize NULL VM context.\n");
        // In a real application, might return an error code or use assert
        exit(EXIT_FAILURE); // Or handle more gracefully
    }

    DEBUG_LOG("Initializing VM...");

    // Clear the entire VM context structure first
    memset(vm, 0, sizeof(DesfVirtualMachine));

    // Initialize VM state
    vm->state.pc = 0;
    vm->state.status_flags = 0;
    // Default optimizations - allow overriding via config later
    vm->state.optimizations = DESF_OPT_NONE;
    // Initialize registers to zero
    memset(vm->state.registers, 0, sizeof(vm->state.registers));

    // Initialize memory
    if (init_mem) {
        DEBUG_LOG("Initializing memory from provided image...");
        _vectorized_memcpy(vm->state.memory, init_mem, DESF_MEM_SIZE);
    } else {
        DEBUG_LOG("Zero-initializing memory...");
        memset(vm->state.memory, 0, DESF_MEM_SIZE);
    }

    // Initialize device and plugin counts
    vm->num_devices = 0;
    // vm->num_plugins = 0; // Assuming num_plugins exists in struct

    // Initialize stack pointer (R15)
    vm->state.registers[STACK_REG_INDEX] = STACK_START_ADDRESS;
    DEBUG_LOG("Stack pointer (R%d) initialized to 0x%X", STACK_REG_INDEX, STACK_START_ADDRESS);

    // Initialize JIT/Cache subsystems if enabled (placeholders)
    if (vm->state.optimizations & DESF_OPT_JIT_ENABLE) {
        _jit_init(vm);
    }
    if (vm->state.optimizations & DESF_OPT_CACHE_ENABLE) {
        _cache_init(vm);
    }

    DEBUG_LOG("VM Initialization Complete.");
}

/**
 * @brief Execute a DESF program.
 */
int desf_vm_execute(DesfVirtualMachine *vm, const DesfCommand *program, size_t count) {
    if (!vm || !program) {
        fprintf(stderr, "Fatal Error: Cannot execute with NULL VM or program.\n");
        return VM_ERR_INVALID_OPERAND; // Return error code
    }

    DEBUG_LOG("Starting execution. Program size: %zu commands.", count);
    vm->state.status_flags &= ~(DESF_STATUS_HALT | DESF_STATUS_ERROR); // Clear flags

    // Main execution loop
    while (!(vm->state.status_flags & DESF_STATUS_HALT)) {
        // 1. Check PC bounds
        if (DESF_UNLIKELY(vm->state.pc >= count)) {
            VM_ERROR_LOG(vm, VM_ERR_OUT_OF_BOUNDS, "Program counter out of bounds");
            break; // Exit loop on error
        }

        // 2. Attempt JIT execution (if enabled)
        bool executed_by_jit = false;
        if (vm->state.optimizations & DESF_OPT_JIT_ENABLE) {
            executed_by_jit = _jit_execute_block(vm);
            // If JIT executed, it should have updated PC and flags.
            // If it returns true, we skip interpretation for this cycle.
        }

        // 3. Interpret instruction if JIT didn't handle it
        if (!executed_by_jit) {
            const DesfCommand current_cmd = program[vm->state.pc];
            uint32_t pc_before_exec = vm->state.pc;

            DEBUG_LOG("Executing Opcode %d at PC=0x%04X (Op1=%d, Op2=%d, Op3=%d, Mode=0x%X)",
                      current_cmd.type, pc_before_exec, current_cmd.operand1,
                      current_cmd.operand2, current_cmd.operand3, current_cmd.mode);

            _execute_instruction(vm, &current_cmd);

            // If instruction didn't modify PC (not jump/call/ret/error), increment PC
            if (!(vm->state.status_flags & DESF_STATUS_HALT) && vm->state.pc == pc_before_exec) {
                vm->state.pc++;
            }
        }

        // 4. Optional: Debugging hooks / cycle limits
        // if (vm->debug_mode) { _dump_registers(vm); }
        // if (++cycle_count > MAX_CYCLES) { VM_ERROR_LOG(vm, VM_ERR_TIMEOUT, "Execution timeout"); break; }

    } // End while loop

    DEBUG_LOG("Execution finished. Final PC=0x%04X, Flags=0x%02X",
              vm->state.pc, vm->state.status_flags);

    // Optional: Shutdown subsystems
    if (vm->state.optimizations & DESF_OPT_JIT_ENABLE) {
        _jit_shutdown(vm);
    }
    if (vm->state.optimizations & DESF_OPT_CACHE_ENABLE) {
        _cache_shutdown(vm);
    }

    // Return status
    if (vm->state.status_flags & DESF_STATUS_ERROR) {
        return VM_ERR_UNKNOWN; // General error occurred
    }
    if (vm->state.status_flags & DESF_STATUS_HALT) {
        return VM_ERR_OK; // Halted normally (or due to error, handled above)
    }

    // Should not be reached if loop logic is correct
    return VM_ERR_UNKNOWN;
}

/**
 * @brief Map a hardware device into the VM's memory space.
 */
int desf_vm_map_device(DesfVirtualMachine *vm, DesfIOHandler handler, uint32_t base_address) {
    if (!vm || !handler) {
        return VM_ERR_INVALID_OPERAND;
    }
    if (vm->num_devices >= DESF_MAX_DEVICES) {
        // Use VM_ERROR_LOG for consistency, but return specific code
        VM_ERROR_LOG(vm, VM_ERR_DEVICE_MAP_FAILED, "Maximum number of devices reached");
        return VM_ERR_DEVICE_MAP_FAILED;
    }
    // Basic validity check for base address
    if (base_address >= DESF_MEM_SIZE) {
         VM_ERROR_LOG(vm, VM_ERR_DEVICE_MAP_FAILED, "Invalid base address for device (out of bounds)");
         return VM_ERR_DEVICE_MAP_FAILED;
    }
    // TODO: Add checks for address range overlap with existing devices/memory regions.
    // This requires storing device size/range information.

    vm->devices[vm->num_devices].handler = handler;
    vm->devices[vm->num_devices].base_address = base_address;
    vm->num_devices++;

    DEBUG_LOG("Mapped device %zu at base address 0x%X", vm->num_devices, base_address);
    return VM_ERR_OK;
}

/**
 * @brief Load a plugin into the VM.
 */
int desf_vm_load_plugin(DesfVirtualMachine *vm, DesfPluginHandler handler) {
    if (!vm || !handler) {
        return VM_ERR_INVALID_OPERAND;
    }

    // Find an empty plugin slot
    size_t i;
    int loaded_slot = -1;
    for (i = 0; i < DESF_MAX_PLUGINS; ++i) {
        if (vm->plugins[i] == NULL) {
            vm->plugins[i] = handler;
            loaded_slot = (int)i;
            break;
        }
    }

    if (loaded_slot == -1) {
        VM_ERROR_LOG(vm, VM_ERR_PLUGIN_LOAD_FAILED, "Maximum number of plugins reached");
        return VM_ERR_PLUGIN_LOAD_FAILED;
    }

    DEBUG_LOG("Loaded plugin into slot %d", loaded_slot);

    // Call plugin initialization function (example)
    int init_status = handler(vm, PLUGIN_REASON_INIT, NULL);
    if (init_status != 0) {
        DEBUG_LOG("Plugin in slot %d failed to initialize (status %d). Unloading.", loaded_slot, init_status);
        vm->plugins[loaded_slot] = NULL; // Unload on init failure
        // Don't set VM error flag here, let caller decide based on return code
        return VM_ERR_PLUGIN_LOAD_FAILED;
    }

    DEBUG_LOG("Plugin in slot %d initialized successfully.", loaded_slot);
    return VM_ERR_OK;
}

/**
 * @brief Read data from VM memory (handles device mapping).
 */
int desf_vm_mem_read(const DesfVirtualMachine *vm, uint32_t address, uint8_t *buffer, size_t size) {
    if (!vm || !buffer) {
        return VM_ERR_INVALID_OPERAND;
    }
    // Cast away const for internal helper that might call non-const device handlers
    DesfVirtualMachine *non_const_vm = (DesfVirtualMachine *)vm;
    return _handle_memory_access(non_const_vm, address, buffer, size, false); // false = read
}

/**
 * @brief Write data to VM memory (handles device mapping).
 */
int desf_vm_mem_write(DesfVirtualMachine *vm, uint32_t address, const uint8_t *data, size_t size) {
    if (!vm || !data) {
        return VM_ERR_INVALID_OPERAND;
    }
    // Cast needed as _handle_memory_access expects uint8_t* for buffer
    return _handle_memory_access(vm, address, (uint8_t *)data, size, true); // true = write
}

//==========================================================
//           Internal Helper Function Implementations
//==========================================================

/**
 * @brief Checks if a memory address and size fall within valid bounds.
 */
DESF_ALWAYS_INLINE static bool _is_address_valid(uint32_t address, size_t size) {
    // Check for basic bounds and potential overflow when calculating end address
    if (size == 0) return true; // Zero size access is technically valid at any address? Or should be error? Assume OK for now.
    if (address >= DESF_MEM_SIZE || size > DESF_MEM_SIZE) {
        return false;
    }
    // Check for wrap-around using subtraction: address must be <= MEM_SIZE - size
    if (address > DESF_MEM_SIZE - size) {
         return false;
    }
    return true;
}

/**
 * @brief Internal unified memory access handler (read/write).
 * Checks for device mappings before accessing main memory.
 * Handles potential cache interactions.
 */
static int _handle_memory_access(DesfVirtualMachine *vm, uint32_t address, uint8_t *buffer, size_t size, bool is_write) {
    // 1. Check overall bounds
    if (!_is_address_valid(address, size)) {
        // Avoid logging error here, let caller handle it based on context
        // VM_ERROR_LOG(vm, VM_ERR_OUT_OF_BOUNDS, "Memory access out of bounds");
        return VM_ERR_OUT_OF_BOUNDS;
    }
    if (size == 0) return VM_ERR_OK; // Nothing to do for zero size

    // 2. Check for device mappings
    // TODO: Implement proper device range checking (requires device size info)
    for (size_t i = 0; i < vm->num_devices; ++i) {
        uint32_t dev_base = vm->devices[i].base_address;
        // Simple check: assumes device handles accesses starting at its base
        // Needs enhancement for devices spanning multiple addresses.
        if (address >= dev_base /* && address < dev_base + device_size */) {
            DEBUG_LOG("Accessing device %zu at address 0x%X (Write: %d, Size: %zu)", i, address, is_write, size);
            if (vm->devices[i].handler) {
                // Call device handler
                int32_t result = vm->devices[i].handler(address, is_write ? buffer : NULL, size);
                // Handle device read result (assuming handler returns value on read, 0 on write success, <0 on error)
                if (!is_write) {
                    if (result < 0) { // Error from handler
                         VM_ERROR_LOG(vm, VM_ERR_INVALID_DEVICE_OP, "Device handler reported error on read");
                         return VM_ERR_INVALID_DEVICE_OP;
                    }
                    // Copy result to buffer (handle different sizes)
                    if (size <= sizeof(result)) {
                        memcpy(buffer, &result, size);
                    } else {
                        // Handle cases where device returns more data? Or error?
                        memset(buffer, 0, size); // Zero out buffer for safety
                        memcpy(buffer, &result, sizeof(result)); // Copy what we have
                    }
                } else { // Write operation
                    if (result < 0) { // Error from handler
                        VM_ERROR_LOG(vm, VM_ERR_INVALID_DEVICE_OP, "Device handler reported error on write");
                        return VM_ERR_INVALID_DEVICE_OP;
                    }
                }
                return VM_ERR_OK; // Handled by device
            } else {
                VM_ERROR_LOG(vm, VM_ERR_INVALID_DEVICE_OP, "Access to device with NULL handler");
                return VM_ERR_INVALID_DEVICE_OP;
            }
        }
    }

    // 3. Access main memory if no device mapped
    DEBUG_LOG("Accessing main memory at 0x%X (Write: %d, Size: %zu)", address, is_write, size);

    // 4. Handle Cache Interaction (Placeholders)
    if (vm->state.optimizations & DESF_OPT_CACHE_ENABLE) {
        if (is_write) {
            // Write through cache or write back policy? Assume write-through for simplicity.
            _cache_write(vm, address, buffer, size);
            // Invalidate other caches if necessary (SMP scenario, unlikely here)
        } else {
            // Attempt cache lookup
            uint8_t* cached_data = _cache_lookup(vm, address, size);
            if (cached_data) {
                DEBUG_LOG("Cache hit for address 0x%X", address);
                _vectorized_memcpy(buffer, cached_data, size);
                return VM_ERR_OK; // Data retrieved from cache
            } else {
                DEBUG_LOG("Cache miss for address 0x%X", address);
                // Data not in cache, proceed to read from main memory
                // After reading, potentially load data into cache (_cache_write or similar)
            }
        }
    }

    // 5. Perform actual memory operation (if not handled by cache read)
    if (is_write) {
        _vectorized_memcpy(vm->state.memory + address, buffer, size);
    } else {
        _vectorized_memcpy(buffer, vm->state.memory + address, size);
        // If cache enabled and read miss occurred, load data into cache now
         if (vm->state.optimizations & DESF_OPT_CACHE_ENABLE) {
             _cache_write(vm, address, buffer, size); // Write fetched data to cache
         }
    }

    return VM_ERR_OK;
}

/**
 * @brief Reads data of specified size from memory. Handles errors and endianness.
 * @param vm VM context.
 * @param address Memory address to read from.
 * @param size Number of bytes to read (1, 2, or 4).
 * @param error Pointer to store error code.
 * @return The value read (zero-extended to int32_t), or 0 on error.
 */
static int32_t _read_memory(DesfVirtualMachine *vm, uint32_t address, size_t size, VMErrorCode *error) {
    uint8_t buffer[4]; // Max read size is 4 bytes for int32_t
    int32_t value = 0;

    if (size != 1 && size != 2 && size != 4) {
        *error = VM_ERR_INVALID_OPERAND; // Invalid size for this helper
        return 0;
    }
    // Optional: Check alignment for word/half-word reads
    if ((size == 2 && (address % 2 != 0)) || (size == 4 && (address % 4 != 0))) {
        // VM_ERROR_LOG(vm, VM_ERR_UNALIGNED_ACCESS, "Unaligned memory read attempted");
        // Decide whether to allow unaligned or raise error. Assume error for now.
        *error = VM_ERR_UNALIGNED_ACCESS;
        return 0;
    }

    int status = _handle_memory_access(vm, address, buffer, size, false); // Read
    if (status != VM_ERR_OK) {
        *error = (VMErrorCode)status;
        return 0;
    }

    // Handle endianness (assuming VM is little-endian, like x86/ARM)
    // If host is big-endian, conversion is needed here.
    // For simplicity, assume host is little-endian.
    if (size == 1) {
        value = (int32_t)buffer[0];
    } else if (size == 2) {
        value = (int32_t)(*(uint16_t*)buffer); // Read as uint16_t
    } else { // size == 4
        value = (*(int32_t*)buffer); // Read as int32_t
    }

    *error = VM_ERR_OK;
    return value;
}

/**
 * @brief Writes data of specified size to memory. Handles errors and endianness.
 * @param vm VM context.
 * @param address Memory address to write to.
 * @param value The 32-bit value to write (only lower bytes used for size 1/2).
 * @param size Number of bytes to write (1, 2, or 4).
 * @return VMErrorCode indicating success or failure.
 */
static VMErrorCode _write_memory(DesfVirtualMachine *vm, uint32_t address, int32_t value, size_t size) {
    uint8_t buffer[4];

    if (size != 1 && size != 2 && size != 4) {
        return VM_ERR_INVALID_OPERAND; // Invalid size
    }
     // Optional: Check alignment for word/half-word writes
    if ((size == 2 && (address % 2 != 0)) || (size == 4 && (address % 4 != 0))) {
        // VM_ERROR_LOG(vm, VM_ERR_UNALIGNED_ACCESS, "Unaligned memory write attempted");
        return VM_ERR_UNALIGNED_ACCESS;
    }

    // Prepare buffer based on size (handle endianness - assume little-endian)
    if (size == 1) {
        buffer[0] = (uint8_t)(value & 0xFF);
    } else if (size == 2) {
        *(uint16_t*)buffer = (uint16_t)(value & 0xFFFF);
    } else { // size == 4
        *(int32_t*)buffer = value;
    }

    return (VMErrorCode)_handle_memory_access(vm, address, buffer, size, true); // Write
}


/** @brief Updates the Zero flag based on the result. */
DESF_ALWAYS_INLINE static void _update_zero_flag(DesfVirtualMachine *vm, int32_t result) {
    if (result == 0) vm->state.status_flags |= DESF_STATUS_ZERO;
    else vm->state.status_flags &= ~DESF_STATUS_ZERO;
}

/** @brief Updates the Carry flag for addition (unsigned). */
DESF_ALWAYS_INLINE static void _update_carry_flag_add(DesfVirtualMachine *vm, uint32_t a, uint32_t b) {
    if ((uint32_t)(a + b) < a) vm->state.status_flags |= DESF_STATUS_CARRY;
    else vm->state.status_flags &= ~DESF_STATUS_CARRY;
}

/** @brief Updates the Carry flag for subtraction (unsigned borrow). */
DESF_ALWAYS_INLINE static void _update_carry_flag_sub(DesfVirtualMachine *vm, uint32_t a, uint32_t b) {
    if (b > a) vm->state.status_flags |= DESF_STATUS_CARRY; // Borrow occurred
    else vm->state.status_flags &= ~DESF_STATUS_CARRY;
}

/** @brief Updates the Overflow flag for signed addition. */
DESF_ALWAYS_INLINE static void _update_overflow_flag_add(DesfVirtualMachine *vm, int32_t a, int32_t b, int32_t result) {
    // Overflow occurs if signs of operands are the same, but sign of result is different.
    if (((a ^ b) & 0x80000000) == 0 && ((a ^ result) & 0x80000000) != 0) {
        // vm->state.status_flags |= DESF_STATUS_OVERFLOW; // Assuming overflow flag exists
    } else {
        // vm->state.status_flags &= ~DESF_STATUS_OVERFLOW;
    }
    (void)vm; (void)a; (void)b; (void)result; // Suppress unused warnings if no overflow flag
}

/** @brief Updates the Overflow flag for signed subtraction. */
DESF_ALWAYS_INLINE static void _update_overflow_flag_sub(DesfVirtualMachine *vm, int32_t a, int32_t b, int32_t result) {
    // Overflow occurs if signs of operands are different, and sign of result is different from sign of 'a'.
     if (((a ^ b) & 0x80000000) != 0 && ((a ^ result) & 0x80000000) != 0) {
        // vm->state.status_flags |= DESF_STATUS_OVERFLOW;
    } else {
        // vm->state.status_flags &= ~DESF_STATUS_OVERFLOW;
    }
     (void)vm; (void)a; (void)b; (void)result; // Suppress unused warnings
}

/** @brief Pushes a 32-bit value onto the stack. */
static VMErrorCode _push_stack(DesfVirtualMachine *vm, int32_t value) {
    uint32_t current_sp = (uint32_t)vm->state.registers[STACK_REG_INDEX];

    if (current_sp < STACK_MIN_ADDRESS + 4) { // Check before decrement
        VM_ERROR_LOG(vm, VM_ERR_STACK_OVERFLOW, "Stack overflow");
        return VM_ERR_STACK_OVERFLOW;
    }
    current_sp -= 4; // Decrement SP (points to new top)
    vm->state.registers[STACK_REG_INDEX] = (int32_t)current_sp;
    DEBUG_LOG("PUSH 0x%X onto stack at 0x%X", value, current_sp);
    return _write_memory(vm, current_sp, value, 4); // Write value
}

/** @brief Pops a 32-bit value from the stack. */
static int32_t _pop_stack(DesfVirtualMachine *vm, VMErrorCode *error) {
    uint32_t current_sp = (uint32_t)vm->state.registers[STACK_REG_INDEX];

    if (current_sp >= STACK_START_ADDRESS) { // Check before reading
        VM_ERROR_LOG(vm, VM_ERR_STACK_UNDERFLOW, "Stack underflow");
        *error = VM_ERR_STACK_UNDERFLOW;
        return 0;
    }

    int32_t value = _read_memory(vm, current_sp, 4, error);
    if (*error != VM_ERR_OK) {
        return 0; // Error occurred during read
    }

    vm->state.registers[STACK_REG_INDEX] = (int32_t)(current_sp + 4); // Increment SP
    DEBUG_LOG("POP 0x%X from stack, new SP=0x%X", value, current_sp + 4);
    *error = VM_ERR_OK;
    return value;
}

/**
 * @brief Decodes an operand based on addressing mode specifier.
 * @param vm VM context.
 * @param operand_spec The operand field from the instruction (can be reg index, immediate, address).
 * @param mode The addressing mode for this operand.
 * @param error Pointer to store error code.
 * @return The final value of the operand.
 */
static int32_t _get_operand_value(DesfVirtualMachine *vm, int32_t operand_spec, AddressingMode mode, VMErrorCode *error) {
    *error = VM_ERR_OK;
    switch (mode) {
        case ADDR_MODE_IMMEDIATE:
            return operand_spec; // Value is the operand itself

        case ADDR_MODE_REGISTER:
            if (DESF_UNLIKELY(operand_spec < 0 || operand_spec >= DESF_MAX_REGISTERS)) {
                *error = VM_ERR_INVALID_OPERAND;
                return 0;
            }
            return vm->state.registers[operand_spec];

        case ADDR_MODE_MEM_DIRECT:
            // Operand spec is the direct memory address
            return _read_memory(vm, (uint32_t)operand_spec, 4, error); // Read 4 bytes by default

        case ADDR_MODE_MEM_REG_INDIRECT:
            // Operand spec is the register holding the memory address
            if (DESF_UNLIKELY(operand_spec < 0 || operand_spec >= DESF_MAX_REGISTERS)) {
                *error = VM_ERR_INVALID_OPERAND;
                return 0;
            }
            uint32_t address = (uint32_t)vm->state.registers[operand_spec];
            return _read_memory(vm, address, 4, error); // Read 4 bytes by default

        // Add cases for other modes like [Reg + Offset], etc.
        // case ADDR_MODE_MEM_REG_OFFSET:
        //    // Needs instruction format to support offset (e.g., operand3)
        //    uint32_t base_reg = operand_spec;
        //    int32_t offset = cmd->operand3; // Assuming offset is in op3
        //    uint32_t address = vm->state.registers[base_reg] + offset;
        //    return _read_memory(vm, address, 4, error);

        default:
            *error = VM_ERR_INVALID_ADDR_MODE;
            return 0;
    }
}

/**
 * @brief Gets the effective memory address specified by an operand.
 * Used for instructions like STORE, LOAD, LEA (Load Effective Address).
 * @param vm VM context.
 * @param operand_spec The operand field from the instruction.
 * @param mode The addressing mode for this operand.
 * @param error Pointer to store error code.
 * @return The calculated memory address, or 0 on error.
 */
static uint32_t _get_operand_address(DesfVirtualMachine *vm, int32_t operand_spec, AddressingMode mode, VMErrorCode *error) {
     *error = VM_ERR_OK;
    switch (mode) {
        case ADDR_MODE_MEM_DIRECT:
            return (uint32_t)operand_spec; // Address is the operand itself

        case ADDR_MODE_MEM_REG_INDIRECT:
            if (DESF_UNLIKELY(operand_spec < 0 || operand_spec >= DESF_MAX_REGISTERS)) {
                *error = VM_ERR_INVALID_OPERAND;
                return 0;
            }
            return (uint32_t)vm->state.registers[operand_spec];

        // Add cases for other modes like [Reg + Offset], etc.
        // case ADDR_MODE_MEM_REG_OFFSET:
        //    uint32_t base_reg = operand_spec;
        //    int32_t offset = cmd->operand3; // Assuming offset is in op3
        //    return vm->state.registers[base_reg] + offset;

        // These modes don't yield an address directly
        case ADDR_MODE_IMMEDIATE:
        case ADDR_MODE_REGISTER:
        default:
            *error = VM_ERR_INVALID_ADDR_MODE; // Cannot get address from this mode
            return 0;
    }
}


/** @brief Vectorized memcpy using architecture-specific intrinsics if available. */
static void _vectorized_memcpy(void* dest, const void* src, size_t size) {
    // (Implementation identical to previous version - AVX/NEON checks)
    uint8_t* d = (uint8_t*)dest;
    const uint8_t* s = (const uint8_t*)src;
#if defined(DESF_HAS_AVX512) && defined(__AVX512F__)
    while (size >= 64) { __m512i v = _mm512_loadu_si512(s); _mm512_storeu_si512(d, v); s+=64; d+=64; size-=64; }
#elif defined(DESF_HAS_AVX2)
    while (size >= 32) { __m256i v = _mm256_loadu_si256((__m256i*)s); _mm256_storeu_si256((__m256i*)d, v); s+=32; d+=32; size-=32; }
#elif defined(DESF_HAS_NEON)
    while (size >= 16) { uint8x16_t v = vld1q_u8(s); vst1q_u8(d, v); s+=16; d+=16; size-=16; }
#endif
    if (size > 0) { memcpy(d, s, size); } // Standard memcpy for remainder
}

/** @brief Dumps register values for debugging. */
static void _dump_registers(const DesfVirtualMachine *vm) {
    fprintf(stderr, "[DEBUG] Registers: ");
    for (int i = 0; i < DESF_MAX_REGISTERS; ++i) {
        fprintf(stderr, "R%02d=0x%08X ", i, vm->state.registers[i]);
        if ((i + 1) % 4 == 0) fprintf(stderr, "\n               "); // Newline every 4 regs
    }
    fprintf(stderr, " Flags=0x%02X (Z=%d C=%d E=%d H=%d)\n",
            vm->state.status_flags,
            (vm->state.status_flags & DESF_STATUS_ZERO) ? 1 : 0,
            (vm->state.status_flags & DESF_STATUS_CARRY) ? 1 : 0,
            (vm->state.status_flags & DESF_STATUS_ERROR) ? 1 : 0,
            (vm->state.status_flags & DESF_STATUS_HALT) ? 1 : 0);
}

/** @brief Handles unknown opcodes. */
static void _handle_unknown_opcode(DesfVirtualMachine *vm, const DesfCommand *cmd) {
     char error_msg[100];
     snprintf(error_msg, sizeof(error_msg), "Unknown opcode encountered: %d", cmd->type);
     VM_ERROR_LOG(vm, VM_ERR_INVALID_OPCODE, error_msg);
}

/** @brief Handles SYSCALL instruction (Placeholder). */
static void _handle_syscall(DesfVirtualMachine *vm, int32_t call_num) {
    DEBUG_LOG("SYSCALL %d invoked", call_num);
    // In a real OS/environment, this would interact with the host system.
    // Example: Print register R0
    if (call_num == 1) { // Syscall 1: Print R0 as integer
        printf("[Syscall Print]: R0 = %d (0x%X)\n", vm->state.registers[0], vm->state.registers[0]);
    } else if (call_num == 2) { // Syscall 2: Print R0 as character
         printf("[Syscall PrintChar]: R0 = %c\n", (char)(vm->state.registers[0] & 0xFF));
    } else if (call_num == 0) { // Syscall 0: Exit VM (alternative to HALT)
         printf("[Syscall Exit]: Exiting VM via syscall 0.\n");
         vm->state.status_flags |= DESF_STATUS_HALT;
    }
    // Add more syscalls: read input, file I/O, etc.
    else {
        VM_ERROR_LOG(vm, VM_ERR_SYSCALL_FAILED, "Unsupported syscall number");
    }
}


//==========================================================
//             Instruction Execution Implementation
//==========================================================

/**
 * @brief Executes a single DESF instruction.
 * @param vm Pointer to the VM context.
 * @param cmd Pointer to the command to execute.
 * @note This function assumes operands and modes are correctly set in the DesfCommand struct.
 * It uses _get_operand_value and _get_operand_address for flexibility.
 * Error checking is crucial within these helpers and this function.
 */
DESF_NOINLINE // Avoid inlining this large function
static void _execute_instruction(DesfVirtualMachine *vm, const DesfCommand *cmd) {
    VMErrorCode error = VM_ERR_OK;
    int32_t val1 = 0, val2 = 0, result = 0;
    uint32_t addr = 0;
    uint32_t target_pc = 0;
    int32_t dest_reg = -1; // Destination register index, if applicable

    // Determine destination register early if common pattern (e.g., Op1 is dest)
    // Adjust based on actual instruction encoding (e.g., using cmd->mode flags)
    if (cmd->operand1 >= 0 && cmd->operand1 < DESF_MAX_REGISTERS) {
         dest_reg = cmd->operand1;
    }

    // --- Main Instruction Dispatch ---
    switch (cmd->type) {
        // --- NOP ---
        case DESF_CMD_NOP: break; // No operation

        // --- Data Movement ---
        case DESF_CMD_MOV: // MOV DestReg, Src(Reg/Imm)
            // Assume Op1 = DestReg, Op2 = Src (Reg or Imm based on mode)
            // AddressingMode src_mode = (cmd->mode & MODE_OP2_IMM) ? ADDR_MODE_IMMEDIATE : ADDR_MODE_REGISTER;
            AddressingMode src_mode = ADDR_MODE_REGISTER; // Simplified: Assume Reg for now
            if (dest_reg == -1) { error = VM_ERR_INVALID_OPERAND; break; }
            val2 = _get_operand_value(vm, cmd->operand2, src_mode, &error);
            if (error == VM_ERR_OK) {
                vm->state.registers[dest_reg] = val2;
                _update_zero_flag(vm, val2);
            }
            break;

        case DESF_CMD_LOAD: // LOAD Rdest, [Address(Direct/RegIndirect)]
            // Assume Op1 = Rdest, Op2 = Address Specifier
            // AddressingMode addr_mode = (cmd->mode & MODE_OP2_MEM_REG) ? ADDR_MODE_MEM_REG_INDIRECT : ADDR_MODE_MEM_DIRECT;
            AddressingMode addr_mode_load = ADDR_MODE_MEM_DIRECT; // Simplified: Assume direct address
            if (dest_reg == -1) { error = VM_ERR_INVALID_OPERAND; break; }
            addr = _get_operand_address(vm, cmd->operand2, addr_mode_load, &error);
            if (error == VM_ERR_OK) {
                 result = _read_memory(vm, addr, 4, &error); // Read 4 bytes
                 if (error == VM_ERR_OK) {
                     vm->state.registers[dest_reg] = result;
                     _update_zero_flag(vm, result);
                 }
            }
            break;

        case DESF_CMD_STORE: // STORE [Address(Direct/RegIndirect)], Src(Reg/Imm)
             // Assume Op1 = Address Specifier, Op2 = Src Value
             // AddressingMode addr_mode_store = (cmd->mode & MODE_OP1_MEM_REG) ? ADDR_MODE_MEM_REG_INDIRECT : ADDR_MODE_MEM_DIRECT;
             // AddressingMode src_mode_store = (cmd->mode & MODE_OP2_IMM) ? ADDR_MODE_IMMEDIATE : ADDR_MODE_REGISTER;
             AddressingMode addr_mode_store = ADDR_MODE_MEM_DIRECT; // Simplified
             AddressingMode src_mode_store = ADDR_MODE_REGISTER;    // Simplified
             addr = _get_operand_address(vm, cmd->operand1, addr_mode_store, &error);
             if (error != VM_ERR_OK) break;
             val2 = _get_operand_value(vm, cmd->operand2, src_mode_store, &error);
             if (error == VM_ERR_OK) {
                 error = _write_memory(vm, addr, val2, 4); // Write 4 bytes
             }
             break;

        // Add LOADB, STOREB, LOADH, STOREH similarly, using size 1 or 2 in _read/_write_memory

        case DESF_CMD_PUSH: // PUSH Src(Reg/Imm)
            // AddressingMode push_src_mode = (cmd->mode & MODE_OP1_IMM) ? ADDR_MODE_IMMEDIATE : ADDR_MODE_REGISTER;
            AddressingMode push_src_mode = ADDR_MODE_REGISTER; // Simplified
            val1 = _get_operand_value(vm, cmd->operand1, push_src_mode, &error);
            if (error == VM_ERR_OK) {
                error = _push_stack(vm, val1);
            }
            break;

        case DESF_CMD_POP: // POP DestReg
            if (dest_reg == -1) { error = VM_ERR_INVALID_OPERAND; break; }
            result = _pop_stack(vm, &error);
            if (error == VM_ERR_OK) {
                vm->state.registers[dest_reg] = result;
                // Optionally update flags based on popped value? Usually not done.
            }
            break;

        // --- Arithmetic ---
        // Assume Op1=DestReg, Op2=Src1(Reg), Op3=Src2(Reg/Imm) for 3-operand
        // Simplified: Op1=Dest/Src1, Op2=Src2 (Reg)
        case DESF_CMD_ADD:
        case DESF_CMD_SUB:
        case DESF_CMD_MUL:
        case DESF_CMD_DIV:
        case DESF_CMD_MOD: // Modulo
            if (dest_reg == -1 || cmd->operand2 < 0 || cmd->operand2 >= DESF_MAX_REGISTERS) {
                 error = VM_ERR_INVALID_OPERAND; break;
            }
            val1 = vm->state.registers[dest_reg]; // Src1 is also Dest
            val2 = vm->state.registers[cmd->operand2]; // Src2

            if (cmd->type == DESF_CMD_ADD) {
                result = val1 + val2;
                vm->state.registers[dest_reg] = result;
                _update_carry_flag_add(vm, (uint32_t)val1, (uint32_t)val2);
                _update_overflow_flag_add(vm, val1, val2, result);
            } else if (cmd->type == DESF_CMD_SUB) {
                result = val1 - val2;
                vm->state.registers[dest_reg] = result;
                _update_carry_flag_sub(vm, (uint32_t)val1, (uint32_t)val2);
                _update_overflow_flag_sub(vm, val1, val2, result);
            } else if (cmd->type == DESF_CMD_MUL) {
                 // TODO: Handle overflow (e.g., 64-bit result?)
                 result = val1 * val2;
                 vm->state.registers[dest_reg] = result;
                 vm->state.status_flags &= ~DESF_STATUS_CARRY; // Clear carry/overflow for simplicity
            } else if (cmd->type == DESF_CMD_DIV || cmd->type == DESF_CMD_MOD) {
                 if (DESF_UNLIKELY(val2 == 0)) { error = VM_ERR_DIV_BY_ZERO; break; }
                 if (cmd->type == DESF_CMD_DIV) result = val1 / val2; // Signed division
                 else result = val1 % val2; // Signed modulo
                 vm->state.registers[dest_reg] = result;
                 vm->state.status_flags &= ~DESF_STATUS_CARRY;
            }
            _update_zero_flag(vm, result);
            break;

        // --- Logical & Bitwise ---
        case DESF_CMD_AND:
        case DESF_CMD_OR:
        case DESF_CMD_XOR:
             if (dest_reg == -1 || cmd->operand2 < 0 || cmd->operand2 >= DESF_MAX_REGISTERS) {
                 error = VM_ERR_INVALID_OPERAND; break;
            }
            val1 = vm->state.registers[dest_reg];
            val2 = vm->state.registers[cmd->operand2];
            if (cmd->type == DESF_CMD_AND) result = val1 & val2;
            else if (cmd->type == DESF_CMD_OR) result = val1 | val2;
            else result = val1 ^ val2;
            vm->state.registers[dest_reg] = result;
            _update_zero_flag(vm, result);
            vm->state.status_flags &= ~DESF_STATUS_CARRY; // Logical ops usually clear carry
            break;

        case DESF_CMD_NOT: // Bitwise NOT DestReg
             if (dest_reg == -1) { error = VM_ERR_INVALID_OPERAND; break; }
             result = ~vm->state.registers[dest_reg];
             vm->state.registers[dest_reg] = result;
             _update_zero_flag(vm, result);
             break;

        case DESF_CMD_SHL: // Logical Shift Left: SHL Rdest, Rcount/Imm
        case DESF_CMD_SHR: // Logical Shift Right: SHR Rdest, Rcount/Imm
        case DESF_CMD_SAR: // Arithmetic Shift Right: SAR Rdest, Rcount/Imm
            // AddressingMode shift_count_mode = (cmd->mode & MODE_OP2_IMM) ? ADDR_MODE_IMMEDIATE : ADDR_MODE_REGISTER;
            AddressingMode shift_count_mode = ADDR_MODE_IMMEDIATE; // Simplified
             if (dest_reg == -1) { error = VM_ERR_INVALID_OPERAND; break; }
             val1 = vm->state.registers[dest_reg]; // Value to shift
             val2 = _get_operand_value(vm, cmd->operand2, shift_count_mode, &error); // Shift count
             if (error != VM_ERR_OK) break;
             if (val2 < 0 || val2 >= 32) { error = VM_ERR_INVALID_OPERAND; break; } // Invalid shift count

             uint32_t u_val1 = (uint32_t)val1;
             uint32_t u_result = 0;
             uint8_t last_shifted_bit = 0;

             if (cmd->type == DESF_CMD_SHL) {
                 if (val2 > 0) last_shifted_bit = (u_val1 >> (32 - val2)) & 1;
                 u_result = u_val1 << val2;
             } else if (cmd->type == DESF_CMD_SHR) {
                 if (val2 > 0) last_shifted_bit = (u_val1 >> (val2 - 1)) & 1;
                 u_result = u_val1 >> val2; // Logical shift right
             } else { // SAR
                 if (val2 > 0) last_shifted_bit = (u_val1 >> (val2 - 1)) & 1;
                 result = val1 >> val2; // Arithmetic shift right (signed)
                 u_result = (uint32_t)result;
             }

             if (cmd->type != DESF_CMD_SAR) result = (int32_t)u_result;
             vm->state.registers[dest_reg] = result;
             _update_zero_flag(vm, result);
             // Update Carry flag with the last bit shifted out
             if (last_shifted_bit) vm->state.status_flags |= DESF_STATUS_CARRY;
             else vm->state.status_flags &= ~DESF_STATUS_CARRY;
             break;

        // --- Comparison ---
        case DESF_CMD_CMP: // CMP Src1(Reg/Imm), Src2(Reg/Imm) - Sets flags like SUB, but doesn't store result
            // AddressingMode cmp_src1_mode = ...; AddressingMode cmp_src2_mode = ...;
            AddressingMode cmp_src1_mode = ADDR_MODE_REGISTER; // Simplified
            AddressingMode cmp_src2_mode = ADDR_MODE_REGISTER; // Simplified
            val1 = _get_operand_value(vm, cmd->operand1, cmp_src1_mode, &error);
            if (error != VM_ERR_OK) break;
            val2 = _get_operand_value(vm, cmd->operand2, cmp_src2_mode, &error);
            if (error != VM_ERR_OK) break;
            result = val1 - val2; // Perform subtraction internally
            _update_zero_flag(vm, result);
            _update_carry_flag_sub(vm, (uint32_t)val1, (uint32_t)val2);
            _update_overflow_flag_sub(vm, val1, val2, result);
            // Update Sign flag if implemented
            break;

        // --- Control Flow ---
        case DESF_CMD_JMP: // JMP TargetAddr(Imm/Reg)
            // AddressingMode jmp_mode = (cmd->mode & MODE_OP1_REG) ? ADDR_MODE_REGISTER : ADDR_MODE_IMMEDIATE;
            AddressingMode jmp_mode = ADDR_MODE_IMMEDIATE; // Simplified
            target_pc = (uint32_t)_get_operand_value(vm, cmd->operand1, jmp_mode, &error);
            if (error == VM_ERR_OK) vm->state.pc = target_pc; // Update PC directly
            else vm->state.pc++; // Error decoding target, proceed to next instruction? Or halt? Halt is safer.
            break;

        // Conditional Jumps (JEQ, JNE, JCS, JCC, JGT, JLT, etc.)
        case DESF_CMD_JEQ: target_pc = (vm->state.status_flags & DESF_STATUS_ZERO) ? cmd->operand1 : vm->state.pc + 1; break;
        case DESF_CMD_JNE: target_pc = !(vm->state.status_flags & DESF_STATUS_ZERO) ? cmd->operand1 : vm->state.pc + 1; break;
        case DESF_CMD_JCS: target_pc = (vm->state.status_flags & DESF_STATUS_CARRY) ? cmd->operand1 : vm->state.pc + 1; break;
        case DESF_CMD_JCC: target_pc = !(vm->state.status_flags & DESF_STATUS_CARRY) ? cmd->operand1 : vm->state.pc + 1; break;
        // Add Jumps based on Signed comparison (requires Sign and Overflow flags)
        // JGT (Jump if Greater): !(Zero || (Sign != Overflow))
        // JLT (Jump if Less Than): (Sign != Overflow)
        // JGE (Jump if Greater or Equal): !(Sign != Overflow)
        // JLE (Jump if Less or Equal): (Zero || (Sign != Overflow))

        // Update PC for conditional jumps (only if condition met, otherwise PC increments naturally)
        if (target_pc != vm->state.pc + 1) {
            // Need to decode target address properly if it can be register
            vm->state.pc = (uint32_t)target_pc; // Simplified: Assume immediate target
        } else {
            vm->state.pc++; // Condition false or it was already next PC
        }
        break; // Break from main switch after handling jump

        case DESF_CMD_CALL: // CALL TargetAddr(Imm/Reg)
            // AddressingMode call_mode = ...;
            AddressingMode call_mode = ADDR_MODE_IMMEDIATE; // Simplified
            target_pc = (uint32_t)_get_operand_value(vm, cmd->operand1, call_mode, &error);
            if (error != VM_ERR_OK) break;
            error = _push_stack(vm, (int32_t)(vm->state.pc + 1)); // Push return address
            if (error == VM_ERR_OK) vm->state.pc = target_pc; // Jump
            break;

        case DESF_CMD_RET: // Return from subroutine
            vm->state.pc = (uint32_t)_pop_stack(vm, &error);
            break;

        // --- System ---
        case DESF_CMD_HALT:
            vm->state.status_flags |= DESF_STATUS_HALT;
            DEBUG_LOG("HALT instruction encountered.");
            break;

        case DESF_CMD_SYSCALL:
            // Assume syscall number is in operand1 (immediate)
            _handle_syscall(vm, cmd->operand1);
            break;

        // --- Unknown ---
        default:
            _handle_unknown_opcode(vm, cmd);
            break;
    } // End main instruction switch

    // --- Post-execution Error Check ---
    if (error != VM_ERR_OK) {
        // Log detailed error based on code
        const char* error_msg = "Execution error";
        switch(error) {
            case VM_ERR_INVALID_OPERAND: error_msg = "Invalid operand/register"; break;
            case VM_ERR_STACK_OVERFLOW: error_msg = "Stack overflow"; break;
            case VM_ERR_STACK_UNDERFLOW: error_msg = "Stack underflow"; break;
            case VM_ERR_DIV_BY_ZERO: error_msg = "Division by zero"; break;
            case VM_ERR_OUT_OF_BOUNDS: error_msg = "Memory access out of bounds"; break;
            case VM_ERR_INVALID_OPCODE: error_msg = "Invalid opcode"; break;
            case VM_ERR_INVALID_DEVICE_OP: error_msg = "Device operation failed"; break;
            case VM_ERR_INVALID_ADDR_MODE: error_msg = "Invalid addressing mode"; break;
            case VM_ERR_UNALIGNED_ACCESS: error_msg = "Unaligned memory access"; break;
            // Add other specific error messages
            default: error_msg = "Unknown execution error code"; break;
        }
        // Error flag and Halt flag should be set by the function that detected the error
        // or by VM_ERROR_LOG if used internally. Re-assert Halt here just in case.
        vm->state.status_flags |= DESF_STATUS_ERROR | DESF_STATUS_HALT;
        DEBUG_LOG("Error during execution: %s (%d)", error_msg, error);
        #ifdef DESF_ENABLE_DEBUG_LOG
        _dump_registers(vm); // Dump registers on error if debugging
        #endif
    }
}


//==========================================================
//             Placeholder JIT/Cache Functions
//==========================================================

// --- JIT Compilation (Placeholders) ---
typedef struct {
    uint32_t desf_pc;      // Original DESF program counter
    uint8_t *native_code; // Pointer to generated native code
    size_t native_size;   // Size of native code
    // Add linking info, usage count (for cache eviction), etc.
} JITBlockInfo;

static JITBlockInfo* g_jit_cache = NULL; // Simple global cache (replace with hash map)
static size_t g_jit_cache_count = 0;
static size_t g_jit_cache_capacity = 128; // Max number of cached blocks

static void _jit_init(DesfVirtualMachine *vm DESF_UNUSED) {
    DEBUG_LOG("JIT Subsystem Initializing (Placeholder)...");
    g_jit_cache = (JITBlockInfo*)calloc(g_jit_cache_capacity, sizeof(JITBlockInfo));
    if (!g_jit_cache) {
        fprintf(stderr, "Error: Failed to allocate JIT cache\n");
        // Disable JIT?
        vm->state.optimizations &= ~DESF_OPT_JIT_ENABLE;
    }
    g_jit_cache_count = 0;
}

static void _jit_shutdown(DesfVirtualMachine *vm DESF_UNUSED) {
     DEBUG_LOG("JIT Subsystem Shutting Down (Placeholder)...");
     if (g_jit_cache) {
         for (size_t i = 0; i < g_jit_cache_count; ++i) {
             if (g_jit_cache[i].native_code) {
                 // Free executable memory (platform specific: munmap/VirtualFree)
                 // free(g_jit_cache[i].native_code); // Incorrect if using mmap!
             }
         }
         free(g_jit_cache);
         g_jit_cache = NULL;
         g_jit_cache_count = 0;
     }
}

static JITBlockInfo* _jit_find_block(uint32_t pc) {
    if (!g_jit_cache) return NULL;
    // Simple linear scan (replace with hash lookup)
    for (size_t i = 0; i < g_jit_cache_count; ++i) {
        if (g_jit_cache[i].desf_pc == pc && g_jit_cache[i].native_code) {
            return &g_jit_cache[i];
        }
    }
    return NULL;
}

static void _jit_add_block(uint32_t pc, uint8_t* code, size_t size) {
     if (!g_jit_cache || g_jit_cache_count >= g_jit_cache_capacity) {
         // Cache full or not initialized - need eviction strategy (LRU etc.)
         DEBUG_LOG("JIT Cache full or not initialized. Cannot add block for PC=0x%X", pc);
         // Free code if allocated? Depends on allocator.
         return;
     }
     // Add to next available slot (simple)
     g_jit_cache[g_jit_cache_count].desf_pc = pc;
     g_jit_cache[g_jit_cache_count].native_code = code;
     g_jit_cache[g_jit_cache_count].native_size = size;
     g_jit_cache_count++;
     DEBUG_LOG("Added JIT block for PC=0x%X (Size: %zu bytes) to cache slot %zu", pc, size, g_jit_cache_count - 1);
}


static void _jit_compile_block(DesfVirtualMachine *vm, uint32_t start_pc) {
    if (!(vm->state.optimizations & DESF_OPT_JIT_ENABLE)) return;
    DEBUG_LOG("JIT compilation requested for PC=0x%X (Not Implemented)", start_pc);
    // Placeholder:
    // 1. Analyze code block (e.g., basic block identification).
    // 2. Translate DESF opcodes to host machine code (x86, ARM). This is the hard part.
    //    - Use an assembler library (like asmjit, DynASM) or generate bytes directly.
    // 3. Allocate executable memory (mmap with PROT_EXEC | PROT_WRITE, or VirtualAlloc).
    // 4. Copy generated code to executable memory.
    // 5. Change memory protection (mprotect to PROT_READ | PROT_EXEC, or VirtualProtect).
    // 6. Add block info to JIT cache (_jit_add_block).

    // Example pseudo-code structure:
    // CodeBuffer buffer; // From assembler library
    // BasicBlock bb = analyze_basic_block(vm->program, start_pc);
    // for each instruction in bb:
    //    translate_instruction_to_native(&buffer, instruction);
    // size_t code_size = buffer.getCodeSize();
    // uint8_t* exec_mem = allocate_executable_memory(code_size);
    // if (!exec_mem) return; // Failed allocation
    // copy_code_to_executable_memory(exec_mem, buffer.getCode(), code_size);
    // make_memory_executable(exec_mem, code_size);
    // _jit_add_block(start_pc, exec_mem, code_size);
}

static bool _jit_execute_block(DesfVirtualMachine *vm) {
     if (!(vm->state.optimizations & DESF_OPT_JIT_ENABLE)) return false;

     JITBlockInfo* block = _jit_find_block(vm->state.pc);
     if (block) {
         DEBUG_LOG("JIT Cache hit for PC=0x%X. Executing native code...", vm->state.pc);
         // --- This is the critical and platform-specific part ---
         // 1. Save VM state (registers, flags) that native code might modify.
         // 2. Setup arguments/context for the native code (e.g., pointer to vm->state).
         // 3. Cast native_code pointer to a function pointer type.
         // 4. Call the native code function.
         // 5. Restore VM state from native code results (updated PC, registers, flags).

         // Example pseudo-code (highly simplified):
         // typedef void (*JitFunction)(DesfVMState*);
         // JitFunction native_func = (JitFunction)block->native_code;
         // native_func(&vm->state); // Call the JITted code
         // // The native code MUST update vm->state.pc and vm->state.status_flags correctly.
         // DEBUG_LOG("Native execution finished. New PC=0x%X, Flags=0x%X", vm->state.pc, vm->state.status_flags);

         // --- Placeholder ---
         printf("[JIT Placeholder]: Would execute native code for PC=0x%X\n", vm->state.pc);
         // Since it's a placeholder, we didn't *actually* execute.
         // To avoid infinite loops, maybe just increment PC past the block?
         // Or just return false to let interpreter handle it. Let's return false.
         // return true; // Return true IF native code was actually executed
         return false; // Placeholder returns false
     } else {
         // Block not in cache, maybe trigger compilation?
         // _jit_compile_block(vm, vm->state.pc); // Compile on miss?
     }
     return false; // Block not found or compilation triggered, interpreter handles this cycle
}

// --- Memory Cache (Placeholders) ---
// Very simple direct-mapped cache example
#define CACHE_NUM_LINES 256
#define CACHE_LINE_SIZE 64 // Must be power of 2
typedef struct {
    bool valid;
    uint32_t tag; // High bits of the address
    uint8_t data[CACHE_LINE_SIZE];
    // Add dirty bit for write-back, LRU counter for set-associative, etc.
} CacheLine;

static CacheLine g_memory_cache[CACHE_NUM_LINES];

static void _cache_init(DesfVirtualMachine *vm DESF_UNUSED) {
    DEBUG_LOG("Memory Cache Subsystem Initializing (Placeholder)...");
    memset(g_memory_cache, 0, sizeof(g_memory_cache)); // Invalidate all lines
}

static void _cache_shutdown(DesfVirtualMachine *vm DESF_UNUSED) {
     DEBUG_LOG("Memory Cache Subsystem Shutting Down (Placeholder)...");
     // If using write-back, need to flush dirty lines here.
}

DESF_ALWAYS_INLINE static uint32_t _cache_get_index(uint32_t address) {
    return (address / CACHE_LINE_SIZE) % CACHE_NUM_LINES;
}

DESF_ALWAYS_INLINE static uint32_t _cache_get_tag(uint32_t address) {
    return address / (CACHE_LINE_SIZE * CACHE_NUM_LINES);
}

DESF_ALWAYS_INLINE static uint32_t _cache_get_offset(uint32_t address) {
    return address % CACHE_LINE_SIZE;
}

static uint8_t* _cache_lookup(DesfVirtualMachine *vm, uint32_t address, size_t size) {
    if (!(vm->state.optimizations & DESF_OPT_CACHE_ENABLE)) return NULL;
    // Simple check: only handle lookups that fit within a single cache line
    if (_cache_get_offset(address) + size > CACHE_LINE_SIZE) {
        DEBUG_LOG("Cache lookup spans multiple lines (Addr=0x%X, Size=%zu) - Cache bypassed", address, size);
        return NULL; // Access spans lines, bypass cache for simplicity
    }

    uint32_t index = _cache_get_index(address);
    uint32_t tag = _cache_get_tag(address);
    CacheLine *line = &g_memory_cache[index];

    if (line->valid && line->tag == tag) {
        // Cache Hit!
        return line->data + _cache_get_offset(address); // Return pointer to data within the cache line
    } else {
        // Cache Miss!
        return NULL;
    }
}

static void _cache_write(DesfVirtualMachine *vm, uint32_t address, const uint8_t* data, size_t size) {
     if (!(vm->state.optimizations & DESF_OPT_CACHE_ENABLE)) return;
     // Handle cache writes. Could be write-through or write-allocate/write-back.
     // Simple Write-Allocate / Write-Through: Load line on miss, then write to cache & memory.

     // Check if access spans lines - bypass if it does for simplicity
     if (_cache_get_offset(address) + size > CACHE_LINE_SIZE) {
         DEBUG_LOG("Cache write spans multiple lines (Addr=0x%X, Size=%zu) - Cache bypassed", address, size);
         // Write directly to main memory (handled by caller: _handle_memory_access)
         return;
     }

     uint32_t index = _cache_get_index(address);
     uint32_t tag = _cache_get_tag(address);
     CacheLine *line = &g_memory_cache[index];
     uint32_t offset = _cache_get_offset(address);

     // Check if the correct line is already loaded (or if line is invalid)
     if (!line->valid || line->tag != tag) {
         // Cache Miss - Load the line from main memory first (Write-Allocate)
         DEBUG_LOG("Cache write miss for Addr=0x%X. Loading line %u.", address, index);
         uint32_t line_start_addr = address - offset;
         // Need to read CACHE_LINE_SIZE bytes from main memory into line->data
         // Be careful: use direct memory access, not _handle_memory_access to avoid recursion!
         if (_is_address_valid(line_start_addr, CACHE_LINE_SIZE)) {
              _vectorized_memcpy(line->data, vm->state.memory + line_start_addr, CACHE_LINE_SIZE);
              line->tag = tag;
              line->valid = true;
              // Set dirty bit if write-back
         } else {
              DEBUG_LOG("Failed to load cache line - address invalid: 0x%X", line_start_addr);
              line->valid = false; // Mark as invalid if load failed
              // Write directly to main memory (handled by caller)
              return;
         }
     }

     // Now write the new data to the cached line
     DEBUG_LOG("Writing %zu bytes to cache line %u, offset %u", size, index, offset);
     _vectorized_memcpy(line->data + offset, data, size);
     // Set dirty bit if write-back

     // For write-through, also write to main memory immediately (handled by caller)
}

static void _cache_invalidate(DesfVirtualMachine *vm, uint32_t address, size_t size) {
    if (!(vm->state.optimizations & DESF_OPT_CACHE_ENABLE)) return;
    // Invalidate cache lines overlapping the given address range.
    // Simple approach: invalidate any line the range touches.
    uint32_t start_addr = address;
    uint32_t end_addr = address + size -1;
    uint32_t current_line_addr = start_addr - _cache_get_offset(start_addr);

    while (current_line_addr <= end_addr) {
        uint32_t index = _cache_get_index(current_line_addr);
        uint32_t tag = _cache_get_tag(current_line_addr);
         CacheLine *line = &g_memory_cache[index];
         // Check if the line is valid and corresponds to the address range being invalidated
         if (line->valid && line->tag == tag) {
             DEBUG_LOG("Invalidating cache line %u (Addr=0x%X)", index, current_line_addr);
             line->valid = false;
             // If write-back, need to write dirty data to memory first!
         }
        current_line_addr += CACHE_LINE_SIZE;
    }
}


// --- End of core.c --- Approx 1500+ lines

