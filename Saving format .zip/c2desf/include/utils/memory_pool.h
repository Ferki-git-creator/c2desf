/**
 * @file memory_pool.h
 * @brief Advanced memory management for DESF ecosystem
 * @author Ferki
 * @license MIT
 * 
 * 🧠 AI-Optimized • 🔐 Quantum-Safe • 📦 Object-Aware
 */

#pragma once

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

//═════════════════════════════════════════════════════════════════════════════
//                            Configuration
//═════════════════════════════════════════════════════════════════════════════

#define MEM_POOL_DEFAULT_SIZE  (4 * 1024 * 1024)  ///< 4MB default pool
#define MAX_QUANTUM_SLICES     8                  ///< For quantum-safe storage
#define AI_PREDICTION_WINDOW   16                 ///< AI lookahead steps

//═════════════════════════════════════════════════════════════════════════════
//                         Quantum Memory Architecture  
//═════════════════════════════════════════════════════════════════════════════

typedef enum {
    MEM_LAYER_CLASSIC,      ///< Standard RAM-like storage
    MEM_LAYER_QUANTUM       ///< Superposition-ready storage
} MemoryLayerType;

typedef struct {
    MemoryLayerType type;
    union {
        struct {
            uint8_t* ptr;
            size_t capacity;
        } classic;
        struct {
            uint64_t qubit_mask; ///< Qubit entanglement map
        } quantum;
    };
} MemoryLayer;

//═════════════════════════════════════════════════════════════════════════════
//                      AI-Driven Allocation Strategies
//═════════════════════════════════════════════════════════════════════════════

typedef struct {
    size_t next_alloc_size;
    uint32_t pattern_hash;
    bool predicted_fragmentation;
} AllocationPrediction;

typedef void (*AIMemoryStrategy)(AllocationPrediction*, const MemoryLayer*);

//═════════════════════════════════════════════════════════════════════════════
//                         Core Memory Pool Structure
//═════════════════════════════════════════════════════════════════════════════

typedef struct {
    MemoryLayer layers[MAX_QUANTUM_SLICES];
    AllocationPrediction ai_predictions[AI_PREDICTION_WINDOW];
    
    struct {
        uint64_t access_pattern;
        uint32_t crc32_checksum;
        uint8_t desf_signature[32]; ///< ED25519-SHA3
    } security;

    AIMemoryStrategy strategy;
    bool auto_defrag;
} DesfMemoryPool;

//═════════════════════════════════════════════════════════════════════════════
//                      Signature & Provenance Tracking
//═════════════════════════════════════════════════════════════════════════════

typedef struct {
    uint8_t source_hash[32];   ///< SHA3-256 of original source code
    uint8_t compiler_id[16];   ///< Compiler version fingerprint
    uint64_t timestamp;        ///< POSIX timestamp with nanoseconds
    char hint[64];             ///< Human-readable hint (e.g., "fridge_controller")
} DesfProvenance;

//═════════════════════════════════════════════════════════════════════════════
//                           Public API
//═════════════════════════════════════════════════════════════════════════════

/**
 * @brief Initialize memory pool with optional AI strategy
 * @param pool Memory pool context
 * @param strategy AI allocation predictor (NULL for default)
 */
void desf_mempool_init(DesfMemoryPool* pool, AIMemoryStrategy strategy);

/**
 * @brief Allocate memory with provenance tracking
 * @param pool Memory pool context
 * @param size Requested size
 * @param provenance Origin metadata (NULL for anonymous)
 * @return Pointer to allocated memory
 */
void* desf_mempool_alloc(DesfMemoryPool* pool, size_t size, const DesfProvenance* provenance);

/**
 * @brief Free memory and update AI model
 * @param pool Memory pool context
 * @param ptr Pointer to release
 */
void desf_mempool_free(DesfMemoryPool* pool, void* ptr);

/**
 * @brief Enable quantum-safe storage layer
 * @param pool Memory pool context
 * @param qubits Number of logical qubits to allocate
 */
void desf_mempool_enable_quantum(DesfMemoryPool* pool, uint8_t qubits);

//═════════════════════════════════════════════════════════════════════════════
//                      Advanced Security Features
//═════════════════════════════════════════════════════════════════════════════

/**
 * @brief Validate memory integrity using quantum-resistant hash
 * @param pool Memory pool context
 * @return True if memory is untampered, False otherwise
 */
bool desf_mempool_validate(const DesfMemoryPool* pool);

/**
 * @brief Rotate memory encryption keys
 * @param pool Memory pool context
 * @param new_key 32-byte encryption key
 */
void desf_mempool_rekey(DesfMemoryPool* pool, const uint8_t new_key[32]);

#ifdef __cplusplus
}
#endif