/**
 * @file x86_jit.c
 * @brief Enhanced x86 JIT Compiler for DESF (Device-Embedded Stream Format)
 * @author Ferki (Original), Gemini (Enhancements)
 * @license MIT
 *
 * 🔥 Ultra-optimized • Context-Aware • Cache-Friendly • Robust 🔄
 *
 * This version incorporates enhancements such as:
 * - Robust error handling and resource cleanup.
 * - Complete x86-64 System V ABI compliant prologue/epilogue.
 * - Basic LRU code cache implementation.
 * - Memory protection using mmap/mprotect (W^X).
 * - Portable instruction cache flushing.
 * - Basic parameter passing assumption (pointers in rdi, rsi).
 * - Example AVX2/SSE2 implementation for ADD command.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <sys/mman.h> // For mmap, mprotect
#include <time.h>     // For seeding random hash (optional)

// --- Stubs for Dependencies (Replace with actual project headers) ---

/**
 * @enum DesfCommandType
 * @brief Example types for DESF commands.
 */
typedef enum {
    DESF_CMD_NOP,
    DESF_CMD_ADD, // Add [rsi] to [rdi] (vectorized)
    DESF_CMD_MUL, // Multiply [rdi] by [rsi] (vectorized)
    DESF_CMD_LOAD_CONST, // Load constant into a conceptual register/memory
    // ... other command types
} DesfCommandType;

/**
 * @struct DesfCommand
 * @brief Represents a single DESF command.
 * @note Actual implementation might have operands, immediate values etc.
 */
typedef struct {
    DesfCommandType type;
    // Add fields for operands, immediate values, destination/source info etc.
    // For simplicity, we assume operands are implicitly pointed to by rdi/rsi
    // passed to the JIT'ted function.
    uint64_t immediate; // Example immediate value
} DesfCommand;

/**
 * @struct MemoryPool
 * @brief Opaque structure for a memory pool (stub).
 */
typedef struct MemoryPool MemoryPool;

/** @brief Creates a memory pool (stub). */
MemoryPool* mempool_create(size_t initial_size) {
    // In a real implementation, this would allocate the pool structure.
    // We return a dummy non-NULL pointer for demonstration.
    return (MemoryPool*)malloc(1); // Needs proper implementation
}

/** @brief Allocates memory from the pool (stub). */
void* mempool_alloc(MemoryPool* pool, size_t size) {
    // This stub uses standard malloc, ignoring the pool.
    // A real implementation would manage memory within the pool's buffer.
    (void)pool; // Unused parameter
    return malloc(size);
}

/** @brief Destroys a memory pool (stub). */
void mempool_destroy(MemoryPool* pool) {
    // In a real implementation, this would free the pool structure and its memory.
    // We free the dummy pointer allocated in create.
    free(pool);
}

// --- End Stubs ---

// --- CPU Feature Detection (using GCC/Clang builtins) ---

/**
 * @brief Checks if the CPU supports a specific feature.
 * @param feature The feature string (e.g., "avx2", "fma").
 * @return True if supported, false otherwise.
 * @note Relies on GCC/Clang specific builtins.
 */
static inline bool cpu_supports(const char* feature) {
#if defined(__GNUC__) || defined(__clang__)
    return __builtin_cpu_supports(feature);
#else
    // Basic fallback for other compilers (assumes no support)
    // A more robust solution would use cpuid instruction directly.
    (void)feature; // Unused
    return false;
#endif
}

// --- Cache Implementation ---

#define JIT_CACHE_ENTRIES 8
#define HASH_SEED 0xDEADBEEFCAFEFEED // Example seed

/**
 * @struct jit_cache_entry
 * @brief Entry in the JIT code cache.
 */
typedef struct {
    uint64_t hash;       ///< Hash of the DESF command sequence.
    void* code_ptr;   ///< Pointer to the executable code.
    size_t   code_size;  ///< Size of the allocated executable memory.
    size_t   actual_code_size; ///< Size of the generated code within the allocation.
    uint64_t last_used;  ///< Timestamp or counter for LRU.
} jit_cache_entry;

/**
 * @struct x86_jit_context
 * @brief Runtime context for JIT compilation.
 */
typedef struct {
    bool has_avx2;          ///< Supports AVX2 vector instructions.
    bool has_fma;           ///< Supports Fused Multiply-Add.
    jit_cache_entry code_cache[JIT_CACHE_ENTRIES]; ///< LRU cache for compiled code blocks.
    uint64_t usage_counter; ///< Simple counter for LRU logic.
} x86_jit_context;

// --- Hashing ---

/**
 * @brief Simple hash function for a DESF program.
 * @param program Array of DESF commands.
 * @param count Number of commands.
 * @return 64-bit hash value.
 * @note This is a basic hash (FNV-1a style). Replace with a more robust one if needed.
 */
static uint64_t hash_program(const DesfCommand* program, size_t count) {
    uint64_t hash = 0xcbf29ce484222325ULL; // FNV offset basis
    const uint64_t prime = 0x100000001b3ULL; // FNV prime

    for (size_t i = 0; i < count; ++i) {
        // Hash based on command type and any relevant operands/immediates
        uint8_t* byte_ptr = (uint8_t*)&program[i];
        size_t cmd_size = sizeof(DesfCommand); // Adjust if commands have variable size info
        for(size_t j = 0; j < cmd_size; ++j) {
            hash ^= byte_ptr[j];
            hash *= prime;
        }
    }
    return hash;
}

// --- Cache Management ---

/**
 * @brief Finds a compiled function in the cache.
 * @param ctx JIT context.
 * @param hash Hash of the program to find.
 * @return Pointer to the cache entry if found, NULL otherwise. Updates LRU counter.
 */
static jit_cache_entry* find_in_cache(x86_jit_context* ctx, uint64_t hash) {
    for (int i = 0; i < JIT_CACHE_ENTRIES; ++i) {
        if (ctx->code_cache[i].code_ptr != NULL && ctx->code_cache[i].hash == hash) {
            ctx->code_cache[i].last_used = ++ctx->usage_counter; // Update usage
            return &ctx->code_cache[i];
        }
    }
    return NULL;
}

/**
 * @brief Adds a compiled function to the cache, evicting the LRU entry if full.
 * @param ctx JIT context.
 * @param hash Hash of the program.
 * @param code_ptr Pointer to the executable code.
 * @param code_size Size of the allocated memory block.
 * @param actual_code_size Size of the generated code.
 */
static void add_to_cache(x86_jit_context* ctx, uint64_t hash, void* code_ptr, size_t code_size, size_t actual_code_size) {
    int lru_index = 0;
    uint64_t min_used = UINT64_MAX;

    // Find an empty slot or the LRU slot
    for (int i = 0; i < JIT_CACHE_ENTRIES; ++i) {
        if (ctx->code_cache[i].code_ptr == NULL) {
            lru_index = i; // Found empty slot
            min_used = 0; // Ensure this slot is chosen
            break;
        }
        if (ctx->code_cache[i].last_used < min_used) {
            min_used = ctx->code_cache[i].last_used;
            lru_index = i;
        }
    }

    // Evict LRU entry if necessary
    if (ctx->code_cache[lru_index].code_ptr != NULL) {
        // Unmap the memory of the evicted entry
        munmap(ctx->code_cache[lru_index].code_ptr, ctx->code_cache[lru_index].code_size);
        fprintf(stderr, "JIT Cache: Evicted entry with hash 0x%lx\n", ctx->code_cache[lru_index].hash);
    }

    // Add the new entry
    ctx->code_cache[lru_index].hash = hash;
    ctx->code_cache[lru_index].code_ptr = code_ptr;
    ctx->code_cache[lru_index].code_size = code_size;
    ctx->code_cache[lru_index].actual_code_size = actual_code_size;
    ctx->code_cache[lru_index].last_used = ++ctx->usage_counter;

    fprintf(stderr, "JIT Cache: Added entry with hash 0x%lx at index %d\n", hash, lru_index);
}

// --- Code Generation Utilities ---

/**
 * @brief Allocates executable memory using mmap.
 * @param size Requested memory size.
 * @return Pointer to memory with R/W permissions, or MAP_FAILED on error.
 */
static void* alloc_rw_mem(size_t size) {
    // Allocate with Read/Write permissions first
    void* ptr = mmap(NULL, size, PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (ptr == MAP_FAILED) {
        perror("mmap failed");
        return MAP_FAILED;
    }
    return ptr;
}

/**
 * @brief Changes memory protection to Read/Execute.
 * @param ptr Pointer to the memory block.
 * @param size Size of the memory block.
 * @return 0 on success, -1 on failure.
 */
static int protect_rx_mem(void* ptr, size_t size) {
    if (mprotect(ptr, size, PROT_READ | PROT_EXEC) == -1) {
        perror("mprotect failed");
        return -1;
    }
    return 0;
}

/**
 * @brief Emits x86-64 System V ABI compliant prologue.
 * @param buf Pointer to the current position in the code buffer. Updated afterwards.
 * @param stack_size Additional stack space needed (beyond saved registers).
 *
 * Saves RBP, sets up stack frame. Assumes RDI, RSI, RDX etc hold arguments.
 * Does NOT save callee-saved registers here; saving happens in compile_command if needed.
 */
static void emit_prologue(uint8_t** buf, size_t stack_size) {
    uint8_t* p = *buf;
    *p++ = 0x55;                   // push rbp
    *p++ = 0x48; *p++ = 0x89; *p++ = 0xE5; // mov rbp, rsp

    if (stack_size > 0) {
        // Align stack allocation if needed (must be 16-byte aligned before call)
        // This simple version just subtracts; real alignment might be needed.
        if (stack_size <= 127) {
            *p++ = 0x48; *p++ = 0x83; *p++ = 0xEC; *p++ = (uint8_t)stack_size; // sub rsp, imm8
        } else {
            *p++ = 0x48; *p++ = 0x81; *p++ = 0xEC; // sub rsp, imm32
            *(uint32_t*)p = (uint32_t)stack_size;
            p += 4;
        }
    }
    *buf = p;
}

/**
 * @brief Emits x86-64 System V ABI compliant epilogue.
 * @param buf Pointer to the current position in the code buffer. Updated afterwards.
 * @param stack_size Additional stack space allocated in prologue.
 *
 * Restores RSP, RBP and returns.
 * Does NOT restore callee-saved registers here; happens in compile_command if needed.
 */
static void emit_epilogue(uint8_t** buf, size_t stack_size) {
     uint8_t* p = *buf;
     if (stack_size > 0) {
        // Deallocate stack space allocated in prologue
        if (stack_size <= 127) {
            *p++ = 0x48; *p++ = 0x83; *p++ = 0xC4; *p++ = (uint8_t)stack_size; // add rsp, imm8
        } else {
            *p++ = 0x48; *p++ = 0x81; *p++ = 0xC4; // add rsp, imm32
            *(uint32_t*)p = (uint32_t)stack_size;
            p += 4;
        }
    }
    // Can also use: mov rsp, rbp
    // *p++ = 0x48; *p++ = 0x89; *p++ = 0xEC; // mov rsp, rbp
    *p++ = 0x5D;                   // pop rbp
    *p++ = 0xC3;                   // ret
    *buf = p;
}


/**
 * @brief Flushes the instruction cache for the given memory range.
 * @param start Start address of the code.
 * @param end End address of the code (exclusive).
 * @note Uses compiler-specific intrinsics or OS functions.
 */
static void flush_instruction_cache(void* start, void* end) {
    size_t size = (uintptr_t)end - (uintptr_t)start;
#if defined(__GNUC__) || defined(__clang__)
    // __builtin___clear_cache is for the range [start, end)
    __builtin___clear_cache((char*)start, (char*)end);
#elif defined(_WIN32)
    // Windows specific
    #include <windows.h>
    FlushInstructionCache(GetCurrentProcess(), start, size);
#else
    #warning "Instruction cache flushing not implemented for this platform. JIT code might not execute correctly."
    // Consider architecture-specific instructions (e.g., M1's sys_icache_invalidate)
    // or potentially accept the risk if the OS handles it implicitly (less reliable).
#endif
}


// --- Core JIT Compilation ---

/**
 * @enum CompileErrorCode
 * @brief Error codes for compilation failures.
 */
typedef enum {
    COMPILE_OK = 0,
    COMPILE_ERR_UNKNOWN_COMMAND = -1,
    COMPILE_ERR_BUFFER_OVERFLOW = -2,
    COMPILE_ERR_UNSUPPORTED_FEATURE = -3,
    // ... other error codes
} CompileErrorCode;

/**
 * @brief Compiles a single DESF command to x86 machine code.
 * @param ctx JIT context with optimization flags.
 * @param cmd DESF command to compile.
 * @param buf Pointer to the pointer to the current position in the code buffer. Updated.
 * @param buf_end Pointer to the end of the code buffer (for bounds checking).
 * @return CompileErrorCode (COMPILE_OK on success).
 *
 * @note Assumes System V ABI: args in RDI, RSI, RDX, RCX, R8, R9.
 * For simplicity, ADD/MUL assume operands are arrays of doubles
 * pointed to by RDI (src/dst) and RSI (src).
 * This function might need to save/restore callee-saved registers if it uses them.
 */
static CompileErrorCode compile_command(x86_jit_context* ctx,
                                        const DesfCommand* cmd,
                                        uint8_t** buf,
                                        const uint8_t* buf_end) {
    uint8_t* p = *buf;
    const size_t MAX_INST_SIZE = 16; // Max typical x86 instruction size

    // Check buffer space before emitting *any* instruction for this command
    if (p + MAX_INST_SIZE > buf_end) {
        fprintf(stderr, "JIT Error: Code buffer overflow estimate.\n");
        return COMPILE_ERR_BUFFER_OVERFLOW;
    }

    switch (cmd->type) {
        case DESF_CMD_ADD:
            // Adds double-precision floats pointed to by RSI into array pointed by RDI.
            // Assumes data is aligned for AVX/SSE.
            // Operates on one vector/element per command for simplicity.
            // A real JIT would likely handle loops or batch operations.
            if (ctx->has_avx2) {
                // Use YMM registers (256-bit, 4 doubles)
                // vmovapd ymm0, [rdi]      ; Load 4 doubles from address in RDI
                // vmovapd ymm1, [rsi]      ; Load 4 doubles from address in RSI
                // vaddpd ymm0, ymm0, ymm1  ; Add packed doubles
                // vmovapd [rdi], ymm0      ; Store result back to address in RDI
                const uint8_t code[] = {
                    0xC5, 0xF9, 0x28, 0x07,       // vmovapd ymm0, [rdi]
                    0xC5, 0xF9, 0x28, 0x0E,       // vmovapd ymm1, [rsi]
                    0xC5, 0 ED, 0x58, 0xC1,       // vaddpd ymm0, ymm0, ymm1 (Note: ED byte depends on reg/reg or reg/mem)
                    // Let's use reg,reg version: C5 F5 58 C1 for vaddpd ymm0, ymm0, ymm1
                    // Corrected sequence assuming ymm0, ymm1 loaded:
                    // 0xC5, 0xF9, 0x28, 0x07,       // vmovapd ymm0, [rdi]
                    // 0xC5, 0xF9, 0x28, 0x0E,       // vmovapd ymm1, [rsi] - Use ymm1
                    // 0xC5, 0 F5, 0x58, 0xC1,       // vaddpd ymm0, ymm0, ymm1
                    // 0xC5, 0xF9, 0x29, 0x07,       // vmovapd [rdi], ymm0

                    // Corrected sequence using VEX encoding more carefully
                    0xC5, 0xFD, 0x28, 0x07,       // vmovapd ymm0, [rdi] (VEX.256.66.0F.WIG 28 /r)
                    0xC5, 0xFD, 0x28, 0x0E,       // vmovapd ymm1, [rsi] (VEX.256.66.0F.WIG 28 /r)
                    0xC5, 0xF5, 0x58, 0xC1,       // vaddpd ymm0, ymm0, ymm1 (VEX.256.66.0F.W1 58 /r)
                    0xC5, 0xFD, 0x29, 0x07,       // vmovapd [rdi], ymm0 (VEX.256.66.0F.WIG 29 /r)
                };
                memcpy(p, code, sizeof(code));
                p += sizeof(code);
            } else {
                // Fallback to SSE2 (128-bit, 2 doubles)
                // movapd xmm0, [rdi]
                // movapd xmm1, [rsi]
                // addpd xmm0, xmm1
                // movapd [rdi], xmm0
                const uint8_t code[] = {
                    0x66, 0x0F, 0x28, 0x07,       // movapd xmm0, [rdi]
                    0x66, 0x0F, 0x28, 0x0E,       // movapd xmm1, [rsi]
                    0x66, 0x0F, 0x58, 0xC1,       // addpd xmm0, xmm1
                    0x66, 0x0F, 0x29, 0x07,       // movapd [rdi], xmm0
                };
                memcpy(p, code, sizeof(code));
                p += sizeof(code);
            }
            break;

        case DESF_CMD_MUL:
            // Placeholder: Generate code for vector multiplication (vmulpd/mulpd)
            // Similar structure to ADD, loading from [rdi], [rsi] and storing to [rdi]
             if (ctx->has_avx2) {
                 // vmulpd ymm0, ymm0, ymm1 (after loading)
                 // 0xC5, 0xF5, 0x59, 0xC1
                 // Full sequence needed (load, mul, store)
             } else {
                 // mulpd xmm0, xmm1 (after loading)
                 // 0x66, 0x0F, 0x59, 0xC1
                 // Full sequence needed (load, mul, store)
             }
             // For now, just emit NOPs as a placeholder
             *p++ = 0x90; // NOP
             *p++ = 0x90; // NOP
             fprintf(stderr, "JIT Warning: DESF_CMD_MUL not fully implemented.\n");
            break;

        case DESF_CMD_LOAD_CONST:
            // Placeholder: Load cmd->immediate into a conceptual register or memory location.
            // This is highly dependent on how the JIT manages state/registers.
            // Example: mov rax, immediate_value (if result needed in rax)
            // 0x48, 0xB8, [8 bytes immediate]
            *p++ = 0x90; // NOP placeholder
            fprintf(stderr, "JIT Warning: DESF_CMD_LOAD_CONST not implemented.\n");
            break;

         case DESF_CMD_NOP:
            *p++ = 0x90; // NOP
            break;

        default:
            fprintf(stderr, "JIT Error: Unknown DESF command type: %d\n", cmd->type);
            return COMPILE_ERR_UNKNOWN_COMMAND;
    }

    // Final check for actual buffer overflow after writing
    if (p > buf_end) {
         fprintf(stderr, "JIT Error: Code buffer overflow occurred.\n");
         // This indicates MAX_INST_SIZE was too small or logic error
         return COMPILE_ERR_BUFFER_OVERFLOW;
    }

    *buf = p; // Update the buffer pointer
    return COMPILE_OK;
}

/**
 * @brief JIT-compiles a DESF program to native x86-64 code.
 * @param ctx Initialized JIT context.
 * @param program DESF command array.
 * @param count Number of commands.
 * @param initial_code_buffer_size Initial size for the code buffer.
 * @param[out] out_code_size Pointer to store the actual size of the generated code.
 * @return Executable function pointer, or NULL on failure. The function expects
 * arguments according to the System V ABI (e.g., pointers in RDI, RSI).
 *
 * @note Uses mmap/mprotect for executable memory. Manages a simple LRU cache.
 */
void* x86_jit_compile(x86_jit_context* ctx,
                     const DesfCommand* program,
                     size_t count,
                     size_t initial_code_buffer_size,
                     size_t* out_code_size) {

    if (!ctx || !program || count == 0 || !out_code_size) {
        fprintf(stderr, "JIT Error: Invalid arguments to x86_jit_compile.\n");
        return NULL;
    }

    // 1. Check Cache
    uint64_t program_hash = hash_program(program, count);
    jit_cache_entry* cached = find_in_cache(ctx, program_hash);
    if (cached) {
        fprintf(stderr, "JIT Cache: Hit for hash 0x%lx\n", program_hash);
        *out_code_size = cached->actual_code_size;
        // Optional: Re-protect as RX if it was made RW for modification (unlikely here)
        // protect_rx_mem(cached->code_ptr, cached->actual_code_size);
        return cached->code_ptr;
    }
    fprintf(stderr, "JIT Cache: Miss for hash 0x%lx\n", program_hash);


    // 2. Allocate Memory (RW initially)
    // Use a memory pool if available and suitable, otherwise direct mmap
    // MemoryPool* pool = mempool_create(initial_code_buffer_size); // If using pool
    // uint8_t* code_buf = mempool_alloc(pool, initial_code_buffer_size);
    // For direct mmap:
    uint8_t* code_buf = (uint8_t*)alloc_rw_mem(initial_code_buffer_size);
    if (code_buf == MAP_FAILED) {
        // mempool_destroy(pool); // If using pool
        return NULL; // alloc_rw_mem already printed error
    }

    uint8_t* current = code_buf;
    const uint8_t* buf_end = code_buf + initial_code_buffer_size;
    CompileErrorCode compile_status = COMPILE_OK;
    size_t stack_size = 0; // Calculate required stack size if needed

    // 3. Generate Code
    emit_prologue(&current, stack_size);

    for (size_t i = 0; i < count; ++i) {
        compile_status = compile_command(ctx, &program[i], &current, buf_end);
        if (compile_status != COMPILE_OK) {
            goto compilation_error; // Jump to cleanup
        }
    }

    emit_epilogue(&current, stack_size);

    // 4. Finalize & Protect Memory
    size_t actual_code_len = current - code_buf;
    if (protect_rx_mem(code_buf, actual_code_len) != 0) {
        // mprotect failed
        goto compilation_error;
    }

    // 5. Flush Instruction Cache
    flush_instruction_cache(code_buf, current);

    // 6. Add to Cache
    // Note: We pass initial_code_buffer_size as the allocated size for munmap later
    add_to_cache(ctx, program_hash, code_buf, initial_code_buffer_size, actual_code_len);

    // Success
    // mempool_destroy(pool); // Destroy pool ONLY if code_buf lifetime is independent
    *out_code_size = actual_code_len;
    return (void*)code_buf;


compilation_error:
    fprintf(stderr, "JIT Compilation failed with code: %d\n", compile_status);
    // Clean up allocated memory
    munmap(code_buf, initial_code_buffer_size); // Unmap memory allocated by mmap
    // mempool_destroy(pool); // If using pool
    *out_code_size = 0;
    return NULL;
}

// --- Initialization & Cleanup ---

/**
 * @brief Initializes the JIT context and detects CPU features.
 * @param ctx Context to initialize.
 */
void x86_jit_init(x86_jit_context* ctx) {
    if (!ctx) return;
    memset(ctx, 0, sizeof(*ctx));
    ctx->has_avx2 = cpu_supports("avx2");
    ctx->has_fma = cpu_supports("fma");
    ctx->usage_counter = 0;
    // Initialize cache entries (pointers to NULL)
    for (int i = 0; i < JIT_CACHE_ENTRIES; ++i) {
        ctx->code_cache[i].code_ptr = NULL;
        ctx->code_cache[i].hash = 0;
        ctx->code_cache[i].last_used = 0;
        ctx->code_cache[i].code_size = 0;
        ctx->code_cache[i].actual_code_size = 0;
    }
    fprintf(stdout, "JIT Init: AVX2=%s, FMA=%s\n",
            ctx->has_avx2 ? "yes" : "no",
            ctx->has_fma ? "yes" : "no");
}

/**
 * @brief Frees resources associated with the JIT context, including cached code.
 * @param ctx JIT context to destroy.
 */
void x86_jit_destroy(x86_jit_context* ctx) {
     if (!ctx) return;
     fprintf(stdout, "JIT Destroy: Cleaning up cache...\n");
     for (int i = 0; i < JIT_CACHE_ENTRIES; ++i) {
        if (ctx->code_cache[i].code_ptr != NULL) {
            munmap(ctx->code_cache[i].code_ptr, ctx->code_cache[i].code_size);
            ctx->code_cache[i].code_ptr = NULL; // Mark as freed
        }
    }
     // No need to free ctx itself, caller manages its allocation.
     memset(ctx, 0, sizeof(*ctx)); // Clear context data
}


// --- Example Usage ---

// Define a function pointer type matching the JIT'ted code's signature
// Assumes it takes two pointers (e.g., to double arrays) and returns void
typedef void (*jit_func_t)(double* data1, double* data2);

int main() {
    x86_jit_context ctx;
    x86_jit_init(&ctx);

    // Example DESF program: Add data2 to data1 twice
    DesfCommand program[] = {
        { .type = DESF_CMD_ADD },
        { .type = DESF_CMD_ADD } // Add again (just for demo)
       // { .type = DESF_CMD_MUL } // Example placeholder
    };
    size_t program_count = sizeof(program) / sizeof(program[0]);
    size_t code_size = 0;
    size_t buffer_estimate = 4096; // Initial buffer size

    printf("Compiling program (hash: 0x%lx)...\n", hash_program(program, program_count));
    void* func_ptr_void = x86_jit_compile(&ctx, program, program_count, buffer_estimate, &code_size);

    if (func_ptr_void) {
        printf("JIT Compilation successful! Code size: %zu bytes.\n", code_size);
        jit_func_t compiled_func = (jit_func_t)func_ptr_void;

        // Prepare some data (ensure alignment if needed by AVX/SSE)
        // Allocate aligned memory if strict alignment is required
        #ifdef _MSC_VER
        double* data1 = _aligned_malloc(4 * sizeof(double), 32); // Align to 32 bytes for YMM
        double* data2 = _aligned_malloc(4 * sizeof(double), 32);
        #else // GCC/Clang
        double* data1 = aligned_alloc(32, 4 * sizeof(double));
        double* data2 = aligned_alloc(32, 4 * sizeof(double));
        #endif


        if (!data1 || !data2) {
             fprintf(stderr, "Failed to allocate aligned memory.\n");
             // No munmap needed here as it's from aligned_alloc/malloc
             x86_jit_destroy(&ctx); // Clean up JIT cache
             return 1;
        }

        // Initialize data
        for(int i=0; i<4; ++i) {
            data1[i] = (double)(i + 1); // [1.0, 2.0, 3.0, 4.0]
            data2[i] = 10.0;            // [10.0, 10.0, 10.0, 10.0]
        }

        printf("Data before: data1[0]=%.1f, data1[1]=%.1f, data1[2]=%.1f, data1[3]=%.1f\n",
               data1[0], data1[1], data1[2], data1[3]);

        // Execute the JIT'ted code
        compiled_func(data1, data2);

        printf("Data after:  data1[0]=%.1f, data1[1]=%.1f, data1[2]=%.1f, data1[3]=%.1f\n",
               data1[0], data1[1], data1[2], data1[3]);
        // Expected result after two ADDs: [21.0, 22.0, 23.0, 24.0]

        // Test cache: Compile again
        printf("\nRe-compiling same program (should hit cache)...\n");
        size_t code_size2 = 0;
        void* func_ptr_void2 = x86_jit_compile(&ctx, program, program_count, buffer_estimate, &code_size2);
        if (func_ptr_void2 == func_ptr_void) {
             printf("Cache hit confirmed!\n");
        } else {
             printf("Cache miss or error during re-compilation.\n");
        }


        // Clean up data memory
        #ifdef _MSC_VER
        _aligned_free(data1);
        _aligned_free(data2);
        #else
        free(data1);
        free(data2);
        #endif

        // Note: Compiled code memory is freed when the context is destroyed
        // or when evicted from cache.
    } else {
        printf("JIT Compilation failed.\n");
    }

    // Destroy context (frees cached code)
    x86_jit_destroy(&ctx);

    return 0;
}

